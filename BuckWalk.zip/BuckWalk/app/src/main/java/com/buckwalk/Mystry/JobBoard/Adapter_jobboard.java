package com.buckwalk.Mystry.JobBoard;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.buckwalk.Mystry.Shoplog.Data_shoplog;
import com.buckwalk.Mystry.Shoplog.Shoplog;
import com.buckwalk.ProofOfVisit;
import com.buckwalk.R;

import org.json.JSONObject;

import java.util.ArrayList;

import static android.view.View.GONE;

/**
 * Created by Nishant on 11-04-2017.
 */

public class Adapter_jobboard extends RecyclerView.Adapter<Adapter_jobboard.Holder> {
    private ArrayList<Data_shoplog> data_jobboards;
    private Context context;
    private LayoutInflater inflater;

    public Adapter_jobboard(ArrayList<Data_shoplog> data_jobboards, Context context) {
        this.data_jobboards = data_jobboards;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (data_jobboards.size() > 0) {
            JobBoard_Fragment.emptytextview.setVisibility(GONE);
        }else if (data_jobboards.size()==0)
        {
            JobBoard_Fragment.emptytextview.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.model_jobboard, parent, false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(Holder holder, final int position) {

        String status = null;
        if (data_jobboards.get(position).getAudit_status().equals("2")) {
            status = "Pending";
        } else if (data_jobboards.get(position).getAudit_status().equals("3")) {
            status = "Processing";
            holder.add_proofbtn.setVisibility(GONE);
        } else if (data_jobboards.get(position).getAudit_status().equals("4")) {
            status = "Completed";
            holder.add_proofbtn.setVisibility(GONE);
        }
        holder.status.setText(status);
        holder.submit_date.setText(data_jobboards.get(position).getSurvey_submit_date());
        holder.shop_fee.setText(data_jobboards.get(position).getShop_fees());
        holder.company_name.setText(data_jobboards.get(position).getShop_rtg());
        holder.location.setText("Location :" + data_jobboards.get(position).getAddress());
        holder.add_proofbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ProofOfVisit.class);
                intent.putExtra("shopname", data_jobboards.get(position).getShop_rtg());
                intent.putExtra("shop_id", data_jobboards.get(position).getShop_id());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data_jobboards.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        private TextView status, submit_date, shop_fee, company_name, location;
        private Button add_proofbtn;

        public Holder(View itemView) {
            super(itemView);
            add_proofbtn = (Button) itemView.findViewById(R.id.jobboard_addproof);
            shop_fee = (TextView) itemView.findViewById(R.id.jobboard_shopfee);
            status = (TextView) itemView.findViewById(R.id.jobboard_status);
            submit_date = (TextView) itemView.findViewById(R.id.jobboard_surveydate);
            company_name = (TextView) itemView.findViewById(R.id.jobboard_compmanyname);
            location = (TextView) itemView.findViewById(R.id.jobboard_location);
            add_proofbtn = (Button) itemView.findViewById(R.id.jobboard_addproof);
        }
    }
}
