package com.buckwalk.Mystry.Shoplog;


import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.Mystry_services;
import com.buckwalk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class Shoplog extends Fragment {
    public static LinearLayout emptytextview;
    public static RecyclerView recyclerView;
    private Adapter_mystry adapter_mystry;
    private LinearLayoutManager manager;
    private HostFile hostFile = new HostFile();
    private RequestQueue requestQueue;
    private String responsefromVolley;
    public ProgressDialog progressDialog;
    private ArrayList<Data_shoplog> data_shoplogArrayList;
    private BroadcastReceiver receiver_showpd, receiver_dismisspd;
    private StringRequest stringRequest;

    public Shoplog() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shoplog, container, false);

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        data_shoplogArrayList = new ArrayList<>();
        progressDialog.setMessage("Getting List");
        progressDialog.show();
        emptytextview = (LinearLayout) view.findViewById(R.id.shoplog_emptytextView);
        recyclerView = (RecyclerView) view.findViewById(R.id.mystry_recyclerview);
        manager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(manager);
        final String url = hostFile.ShopUrl();
        /*final String url = "http://gaganvats.com/Api/all_audit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui";*/
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                responsefromVolley = response;
                Log.d("TEST_SHOPLOG", response + "\n" + url);
                new Asyncvolley_shop().execute();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                if (error instanceof TimeoutError) {
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("Content-Type", "application/json");
                return map;

            }
        };
        requestQueue.add(stringRequest);
        /*recyclerview*/
        receiver_showpd = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressDialog.setMessage("Applying...");
                progressDialog.show();
            }
        };
        getActivity().registerReceiver(receiver_showpd, new IntentFilter("PDshow"));
        receiver_dismisspd = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressDialog.dismiss();
            }
        };
        getActivity().registerReceiver(receiver_dismisspd, new IntentFilter("PDdismiss"));

        return view;
    }

    class Asyncvolley_shop extends AsyncTask<Void, Void, Void> {
        int status;
        JSONArray array_data;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            data_shoplogArrayList.clear();
            try {
                JSONObject jsonObject = new JSONObject(responsefromVolley);
                JSONObject object_meta = jsonObject.getJSONObject("meta");
                status = object_meta.getInt("status");
                array_data = jsonObject.getJSONArray("data");
                for (int i = 0; i < array_data.length(); i++) {
                    JSONObject jsonObject1 = array_data.getJSONObject(i);
                    String shop_id = jsonObject1.getString("shop_id");
                    String shop_due_date = jsonObject1.getString("shop_due_date");
                    String survey_submit_date = jsonObject1.getString("survey_submit_date");
                    String dont_shop_before_date = jsonObject1.getString("dont_shop_before_date");
                    String address = jsonObject1.getString("address");
                    String shop_fees = jsonObject1.getString("shop_fees");
                    String shop_rtg = jsonObject1.getString("shop_rtg");
                    String audit_status = jsonObject1.getString("audit_status");
                    data_shoplogArrayList.add(new Data_shoplog(shop_id, shop_due_date, survey_submit_date, dont_shop_before_date, address, shop_fees, shop_rtg, audit_status));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            if (status == 200) {
                adapter_mystry = new Adapter_mystry(getActivity(), data_shoplogArrayList);
                recyclerView.setAdapter(adapter_mystry);
                progressDialog.dismiss();
            } else if (status == 401) {
                emptytextview.setVisibility(View.VISIBLE);
                Log.d("TEST", String.valueOf(status));
            } else {
                progressDialog.dismiss();
                emptytextview.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(receiver_showpd);
        getActivity().unregisterReceiver(receiver_dismisspd);
    }

}
