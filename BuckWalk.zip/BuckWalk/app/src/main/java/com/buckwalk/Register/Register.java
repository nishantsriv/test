package com.buckwalk.Register;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Home.Home;
import com.buckwalk.Host.HostFile;
import com.buckwalk.LocationFetcher;
import com.buckwalk.Login.Login;
import com.buckwalk.Mystry.Profile.Profile_Fragment;
import com.buckwalk.R;
import com.buckwalk.UserPicture;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.buckwalk.Mystry.Profile.Profile_Fragment.isNetworkAvailable;

public class Register extends AppCompatActivity {

    EditText firstname_edittext;
    EditText lastname_edittext;
    EditText email_edittext;
    EditText phone_edittext;
    EditText location_edittext;
    EditText password_edittext;
    ImageView locationget_btn;
    LocationManager manager;
    Button register_button;

    String fname_string;
    String lname_string;
    String email_string;
    String phone_string;
    String location_string;
    String password_string;
    String image_code;
    String location, city = "", state = "", country = "", postalcode = "";
    String url;
    String responseFromVolly;
    double lat, lng;
    ImageView profile_pic;
    int SELECT_FILE = 1, REQUEST_CAMERA = 0;
    public static Bitmap mainupload;

    String email_validation = "[a-zA-Z0-9._-]+\\@+[a-zA-Z0-9._-]+\\.+[a-z]+";

    public static final int MULTIPLE_PERMISSIONS = 99;
    public ProgressDialog progressdialog;
    private BroadcastReceiver receiver_startservice, receiver_stopservice;
    String[] permissions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

    HostFile hostFile = new HostFile();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationget_btn = (ImageView) findViewById(R.id.register_locationbtn);
        firstname_edittext = (EditText) findViewById(R.id.register_fname_edittext);
        lastname_edittext = (EditText) findViewById(R.id.register_lname_edittext);
        email_edittext = (EditText) findViewById(R.id.register_email_edittext);
        phone_edittext = (EditText) findViewById(R.id.register_mobile_edittext);
        location_edittext = (EditText) findViewById(R.id.register_location_edittext);
        password_edittext = (EditText) findViewById(R.id.register_password_edittext);
        register_button = (Button) findViewById(R.id.register_reg_button);
        profile_pic = (ImageView) findViewById(R.id.register_image);

        firstname_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
        firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname_color), null, null, null);

        firstname_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                email_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                location_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                password_edittext.setHintTextColor(getResources().getColor(R.color.grey));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname_color), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.mail), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phn), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.loc), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_reg), null, null, null);
            }
        });

        lastname_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
                email_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                location_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                password_edittext.setHintTextColor(getResources().getColor(R.color.grey));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname_color), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.mail), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phn), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.loc), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_reg), null, null, null);
            }
        });

        email_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                email_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                location_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                password_edittext.setHintTextColor(getResources().getColor(R.color.grey));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.email_color), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phn), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.loc), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_reg), null, null, null);

            }
        });

        phone_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                email_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
                location_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                password_edittext.setHintTextColor(getResources().getColor(R.color.grey));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.mail), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phone_color), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.loc), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_reg), null, null, null);
            }
        });

        location_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                email_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                location_edittext.setHintTextColor(getResources().getColor(R.color.login_button));
                password_edittext.setHintTextColor(getResources().getColor(R.color.grey));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.mail), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phn), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.location_color), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_reg), null, null, null);
            }
        });

        password_edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                firstname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                lastname_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                email_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                phone_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                location_edittext.setHintTextColor(getResources().getColor(R.color.grey));
                password_edittext.setHintTextColor(getResources().getColor(R.color.login_button));

                firstname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.fname), null, null, null);
                lastname_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.lname), null, null, null);
                email_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.mail), null, null, null);
                phone_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.phn), null, null, null);
                location_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.loc), null, null, null);
                password_edittext.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.password_color), null, null, null);

            }
        });

        profile_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (checkPermissions()) {
                    selectImage();
                } else if (!checkPermissions()) {
                    Toast.makeText(Register.this, "Camera and Storage Permission Denied", Toast.LENGTH_SHORT).show();
                }

            }
        });
        /*Reciever to start progress dialog during location fetch*/
        receiver_startservice = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressdialog = ProgressDialog.show(Register.this, "", "Getting Location");
            }
        };
        registerReceiver(receiver_startservice, new IntentFilter("Startlocationservice"));


        locationget_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermissions()) {

                    getAddress();
                }
//                    getAddress();
                else if (!checkPermissions()) {
                    Toast.makeText(Register.this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*Reciever to stop progress dialog after location fetch*/
        receiver_stopservice = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressdialog.dismiss();
                stopService(new Intent(Register.this, LocationFetcher.class));
                SharedPreferences preferences = getSharedPreferences("Location", MODE_PRIVATE);
                lat = Double.parseDouble(preferences.getString("latitude", null));
                lng = Double.parseDouble(preferences.getString("longitude", null));
                Geocoder geo = new Geocoder(Register.this, Locale.getDefault());
                List<Address> add = new ArrayList<>();
                try {
                    add = geo.getFromLocation(lat, lng, 1);
                    location = add.get(0).getAddressLine(0) + add.get(0).getAddressLine(1);
                    city = add.get(0).getSubAdminArea();
                    state = add.get(0).getAdminArea();
                    country = add.get(0).getCountryName();
                    postalcode = add.get(0).getPostalCode();
                    Toast.makeText(Register.this, location + country + state + city, Toast.LENGTH_SHORT).show();
                    String location_edittext_string = location + "," + city + "," + state + "," + country + "," + postalcode;
                    location_edittext.setText(location_edittext_string.replace("null", ""));


                } catch (IOException e) {
                    e.printStackTrace();
                }
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear();
            }
        };
        registerReceiver(receiver_stopservice, new IntentFilter("Sendlocationbroadcast"));
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fname_string = firstname_edittext.getText().toString().trim();
                lname_string = lastname_edittext.getText().toString().trim();
                email_string = email_edittext.getText().toString().trim();
                phone_string = phone_edittext.getText().toString().trim();
                location_string = location_edittext.getText().toString().trim();
                password_string = password_edittext.getText().toString().trim();


                if (fname_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter first name", Toast.LENGTH_SHORT).show();
                } else if (lname_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter last name", Toast.LENGTH_SHORT).show();
                } else if (email_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter email", Toast.LENGTH_SHORT).show();
                } else if (phone_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter phone number", Toast.LENGTH_SHORT).show();
                } else if (location_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter location", Toast.LENGTH_SHORT).show();
                } else if (password_string.isEmpty()) {
                    Toast.makeText(Register.this, "Please enter password", Toast.LENGTH_SHORT).show();
                } else {
                    if (!email_string.matches(email_validation)) {
                        Toast.makeText(Register.this, "Please enter valid email id", Toast.LENGTH_SHORT).show();
                    } else if (phone_string.length() != 10) {
                        Toast.makeText(Register.this, "Please enter valid phone number", Toast.LENGTH_SHORT).show();
                    } else if (mainupload == null) {
                        Bitmap profile_pic_bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.profile_pic);
                        mainupload = profile_pic_bitmap;
                    } else {
                        progressdialog = ProgressDialog.show(Register.this, "", "Please Wait...");
                        progressdialog.setCancelable(false);
                        image_code = getStringImage(mainupload);
                        System.out.println("XXXX first name = " + fname_string);
                        System.out.println("XXXX last name = " + lname_string);
                        System.out.println("XXXX email name = " + email_string);
                        System.out.println("XXXX phone name = " + phone_string);
                        System.out.println("XXXX location name = " + location_string);
                        System.out.println("XXXX password name = " + password_string);
//                        System.out.println("XXXX image code = "+image_code);
                        RequestQueue queue = Volley.newRequestQueue(Register.this);
                        url = hostFile.registerUser();
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        responseFromVolly = response;
                                        System.out.println("XXX response = " + response);

                                        RegisterAsync registerAsync = new RegisterAsync();
                                        registerAsync.execute(mainupload);

                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressdialog.dismiss();
                                Toast.makeText(Register.this, "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                                if (error instanceof TimeoutError) {
                                    error.printStackTrace();
                                } else if (error instanceof NoConnectionError) {
                                    error.printStackTrace();
                                } else if (error instanceof AuthFailureError) {
                                    error.printStackTrace();
                                } else if (error instanceof ServerError) {
                                    error.printStackTrace();
                                } else if (error instanceof NetworkError) {
                                    error.printStackTrace();
                                } else if (error instanceof ParseError) {
                                    error.printStackTrace();
                                }
                            }
                        }) {
                            @Override
                            public Map<String, String> getParams() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                if (location == null) {
                                    location = location_edittext.getText().toString();
                                } else if (city == null) {
                                    city = "";
                                } else if (state == null) {
                                    state = "";
                                } else if (country == null) {
                                    country = "";
                                } else if (postalcode == null) {
                                    postalcode = "";
                                }

                                params.put("fname", fname_string);
                                params.put("lname", lname_string);
                                params.put("password", password_string);
                                params.put("email", email_string);
                                params.put("location", location_edittext.getText().toString());
                                params.put("mobileno", phone_string);
                                params.put("image", image_code);
                                params.put("city", city);
                                params.put("state", state);
                                params.put("country", country);
                                params.put("pincode", postalcode);
                                System.out.println("XXX params = " + params);
                                return params;
                            }
                        };
                        queue.add(stringRequest);
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (resultCode == Activity.RESULT_OK) {
                if (requestCode == SELECT_FILE) {
                    onSelectFromGalleryResult(data);
                } else if (requestCode == REQUEST_CAMERA) {
                    onCaptureImageResult(data);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public class RegisterAsync extends AsyncTask<Bitmap, Void, Void> {


        public int code;
        public String message;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Bitmap... params) {
            try {
                JSONObject reader = new JSONObject(responseFromVolly);

                code = reader.getInt("status");
                message = reader.getString("msg");

                System.out.println("XXXX code = " + code);
                System.out.println("XXXX message = " + message);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);


            if (code == 200) {
                progressdialog.dismiss();
                Toast.makeText(Register.this, "Successfully register.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Register.this, Login.class);
                startActivity(i);
                finish();
            } else if (code == 401) {
                progressdialog.dismiss();
                Toast.makeText(Register.this, "User already exist.", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Register.this, Login.class);
                startActivity(i);
                finish();
            } else {
                progressdialog.dismiss();
                Toast.makeText(Register.this, "Something went wrong.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case MULTIPLE_PERMISSIONS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    selectImage();
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    private void selectImage() {
        try {
            final CharSequence[] items = {"Camera", "Gallery"};
            final AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
            builder.setTitle("Choose image: ");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int item) {
                    if (items[item].equals("Camera")) {
                        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(intent, REQUEST_CAMERA);
                    } else if (items[item].equals("Gallery")) {
                        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        intent.setType("image/*");
                        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
                    }
                }
            });
            builder.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onSelectFromGalleryResult(Intent data) {
        try {
            final Uri selectedImageUri = data.getData();
            System.out.println("Image uri = " + selectedImageUri);
            /*final InputStream imageStream = getContentResolver().openInputStream(selectedImageUri);
            Bitmap bm;
            bm = BitmapFactory.decodeStream(imageStream);*/
            Bitmap bm = new UserPicture(selectedImageUri, getContentResolver()).getBitmap();
            profile_pic.setImageBitmap(bm);
            mainupload = bm;
            image_code = getStringImage(mainupload);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void onCaptureImageResult(Intent data) {
        try {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            thumbnail.compress(Bitmap.CompressFormat.PNG, 0, bytes);

            File folder = new File(Environment.getExternalStorageDirectory(), "BuckWalk");
            File folder_profile_pic = new File(folder, "Profile Picture");
            File destination = new File(folder_profile_pic, System.currentTimeMillis() + ".jpg");

            if (!folder.exists()) {
                folder.mkdir();
            }
            if (!folder_profile_pic.exists()) {
                folder_profile_pic.mkdir();
            }

            FileOutputStream fo;
            try {
                destination.createNewFile();
                fo = new FileOutputStream(destination);
                fo.write(bytes.toByteArray());
                fo.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            profile_pic.setImageBitmap(thumbnail);
            mainupload = thumbnail;
            image_code = getStringImage(mainupload);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkPermissions() {
        int result;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : permissions) {
            result = ContextCompat.checkSelfPermission(this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);
            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    public class FetchCordinates extends AsyncTask<String, Void, String> {
        ProgressDialog progDailog = null;

        public double lati = 0.0;
        public double longi = 0.0;
        public LocationManager mLocationManager;
        public mLocationListener mListener;

        @Override
        protected void onPreExecute() {

            mListener = new mLocationListener();
            mLocationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mListener);
            progDailog = new ProgressDialog(Register.this);
            progDailog.setMessage("Please Wait while we Fetch your Location...");
            progDailog.setIndeterminate(true);
            progDailog.setCancelable(false);
            progDailog.show();

        }

        @Override
        protected void onCancelled() {
            System.out.println("Cancelled by user!");
            progDailog.dismiss();
            mLocationManager.removeUpdates(mListener);
        }

        @Override
        protected void onPostExecute(String result) {
            progDailog.dismiss();

            Geocoder geo = new Geocoder(Register.this, Locale.getDefault());
            List<Address> add = new ArrayList<>();
            try {
                add = geo.getFromLocation(lati, longi, 1);
                location = add.get(0).getAddressLine(0) + add.get(0).getAddressLine(1);
                city = add.get(0).getSubAdminArea();
                state = add.get(0).getAdminArea();
                country = add.get(0).getCountryName();
                postalcode = add.get(0).getPostalCode();
                Toast.makeText(Register.this, location + country + state + city, Toast.LENGTH_SHORT).show();
                String location_edittext_string = location + "," + city + "," + state + "," + country + "," + postalcode;
                location_edittext.setText(location_edittext_string.replace("null", ""));


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub

            while (this.lati == 0.0) {

            }
            return null;
        }

        public class mLocationListener implements LocationListener {

            @Override
            public void onLocationChanged(Location location) {
                try {
                    lati = location.getLatitude();
                    longi = location.getLongitude();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProviderDisabled(String provider) {
                Log.i("OnProviderDisabled", "OnProviderDisabled");
            }

            @Override
            public void onProviderEnabled(String provider) {
                Log.i("onProviderEnabled", "onProviderEnabled");
            }

            @Override
            public void onStatusChanged(String provider, int status,
                                        Bundle extras) {
                Log.i("onStatusChanged", "onStatusChanged");
            }
        }
    }

    public void showAlertforgps() {
        android.support.v7.app.AlertDialog.Builder alertDialog = new android.support.v7.app.AlertDialog.Builder(this);
        alertDialog.setTitle(R.string.gps_internet);
        alertDialog.setMessage("You need to connect to GPS for accessing your current location.");
        alertDialog.setPositiveButton("Enable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    private void getAddress() {
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            showAlertforgps();
        } else if (!isNetworkAvailable(this)) {
            showAlertforinternet();
        } else {
            startService(new Intent(Register.this, LocationFetcher.class));
            /*FetchCordinates fetchCordinates = new FetchCordinates();
            fetchCordinates.execute();*/
        }
    }

    public void showAlertforinternet() {
        final android.support.v7.app.AlertDialog.Builder alertDialog = new android.support.v7.app.AlertDialog.Builder(this);
        alertDialog.setMessage(R.string.connect_internet);
        alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getAddress();
            }
        });
        alertDialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    @Override
    public void onStop() {
        super.onStop();
        unregisterReceiver(receiver_stopservice);
        unregisterReceiver(receiver_startservice);
    }
}