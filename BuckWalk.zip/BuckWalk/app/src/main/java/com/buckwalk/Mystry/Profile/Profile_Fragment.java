package com.buckwalk.Mystry.Profile;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Host.HostFile;
import com.buckwalk.LocationFetcher;
import com.buckwalk.Mystry.Mystry_services;
import com.buckwalk.R;
import com.buckwalk.Register.Register;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 */
public class Profile_Fragment extends Fragment {
    private EditText firstname, lastname, email, password, address, city, state, country, postal_code, mobile;
    private RadioButton radioButton_paypal, radioButton_nochoice;
    private String email_validation = "[a-zA-Z0-9._-]+\\@+[a-zA-Z0-9._-]+\\.+[a-z]+";
    private Button submitbtn;
    private ImageView password_visibility, getlocation_click;
    private List<Address> address_data;
    private LocationManager manager;
    private BroadcastReceiver receiver_startservice, receiver_stopservice;
    private ProgressDialog progressdialog;
    private Database db = new Database();
    private UserTable userTable = new UserTable();
    private LoginData loginData = new LoginData();
    private LoginDataMapper loginDataMapper = new LoginDataMapper();
    double lat, lng;
    String user_id_db;
    String name_db;
    String fname_db;
    String lname_db;
    String email_db;
    String address_db;
    String city_db;
    String state_db;
    String country_db;
    String postal_code_db;
    String mobile_no_db;

    String responseFromVolly;
    ProgressDialog progressDialog;
    String url;
    HostFile hostFile = new HostFile();
    String fname_update_string, lname_update_string, email_update_string, address_update_string, password_update_string,
            city_update_string, state_update_string, country_update_string,
            postal_update_string, mobile_update_string;


    public Profile_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile_, container, false);
        address_data = new ArrayList<>();
        manager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        getlocation_click = (ImageView) view.findViewById(R.id.profile_getlocation);
        password_visibility = (ImageView) view.findViewById(R.id.profile_passwordvisibility);
        submitbtn = (Button) view.findViewById(R.id.profile_submitbtn);
        radioButton_paypal = (RadioButton) view.findViewById(R.id.profile_paypal_radiobtn);
        radioButton_nochoice = (RadioButton) view.findViewById(R.id.profile_nochoice_radiobtn);
        firstname = (EditText) view.findViewById(R.id.profile_firstname);
        lastname = (EditText) view.findViewById(R.id.profile_lastname);
        email = (EditText) view.findViewById(R.id.profile_emailid);
        password = (EditText) view.findViewById(R.id.profile_password);
        address = (EditText) view.findViewById(R.id.profile_address);
        city = (EditText) view.findViewById(R.id.profile_city);
        state = (EditText) view.findViewById(R.id.profile_state);
        country = (EditText) view.findViewById(R.id.profile_country);
        postal_code = (EditText) view.findViewById(R.id.profile_postalcode);
        mobile = (EditText) view.findViewById(R.id.profile_mobile);
        edittextthemes();
        /*Reciever to start progress dialog during location fetch*/
        receiver_startservice = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressdialog = ProgressDialog.show(getActivity(), "", "Getting Location");
            }
        };
        getActivity().registerReceiver(receiver_startservice, new IntentFilter("Startlocationservice"));

        getlocation_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkForCameraPermission();
            }
        });

        receiver_stopservice = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressdialog.dismiss();
                getActivity().stopService(new Intent(getActivity(), LocationFetcher.class));
                SharedPreferences preferences = getActivity().getSharedPreferences("Location", MODE_PRIVATE);
                lat = Double.parseDouble(preferences.getString("latitude", null));
                lng = Double.parseDouble(preferences.getString("longitude", null));
                Geocoder geo = new Geocoder(getActivity(), Locale.getDefault());
                List<Address> add = new ArrayList<>();
                try {
                    add = geo.getFromLocation(lat, lng, 1);
                    address.setText(add.get(0).getAddressLine(0) + "," + add.get(0).getAddressLine(1));
                    city.setText(add.get(0).getSubAdminArea());
                    state.setText(add.get(0).getAdminArea());
                    country.setText(add.get(0).getCountryName());
                    postal_code.setText(add.get(0).getPostalCode());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        getActivity().registerReceiver(receiver_stopservice, new IntentFilter("Sendlocationbroadcast"));
        loginData = loginDataMapper.getInfo("1");

        user_id_db = loginData.user_id;
        name_db = loginData.name.replaceAll(" ", "-");
        if (name_db.contains("-")) {
            String temp[] = name_db.split("-");
            fname_db = temp[0];
            firstname.setText(fname_db);
            lname_db = temp[1];
            lastname.setText(lname_db);
        } else {
            fname_db = name_db;
            firstname.setText(name_db);
        }

        email_db = loginData.email;
        if (email_db.isEmpty()) {
            email.setText("");
        } else {
            email.setText(email_db);
        }

        address_db = loginData.location;
        if (address_db.isEmpty()) {
            address.setText("");
        } else {
            address.setText(address_db);
        }

        city_db = loginData.city;
        if (city_db.isEmpty()) {
            city.setText("");
        } else {
            city.setText(city_db);
        }

        state_db = loginData.state;
        if (state_db.isEmpty()) {
            state.setText("");
        } else {
            state.setText(state_db);
        }

        country_db = loginData.country;
        if (country_db.isEmpty()) {
            country.setText("");
        } else {
            country.setText(country_db);
        }

        postal_code_db = loginData.pincode;
        if (postal_code_db.isEmpty()) {
            postal_code.setText("");
        } else {
            postal_code.setText(postal_code_db);
        }

        mobile_no_db = loginData.phone;
        if (mobile_no_db.isEmpty()) {
            mobile.setText("");
        } else {
            mobile.setText(mobile_no_db);
        }

        return view;
    }

    private void getAddress() {
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            showAlertforgps();
        } else if (!isNetworkAvailable(getActivity())) {
            showAlertforinternet();
        } else {
            getActivity().startService(new Intent(getActivity(), LocationFetcher.class));
            /*FetchCordinates fetchCordinates = new FetchCordinates();
            fetchCordinates.execute();*/
        }
    }

    public void showAlertforinternet() {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        alertDialog.setMessage(R.string.connect_internet);
        alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getAddress();
            }
        });
        alertDialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    public static boolean isNetworkAvailable(Context context) {
        return ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo() != null;
    }

    private void edittextthemes() {
        firstname.setHintTextColor(getResources().getColor(R.color.mystryColor));
        firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname_selected), null, null, null);
        firstname.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.mystryColor));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname_selected), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        lastname.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.mystryColor));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname_selected), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.mystryColor));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_emailid_selected), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.mystryColor));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password_selected), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        address.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.mystryColor));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address_selected), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        city.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.mystryColor));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city_selected), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        state.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.mystryColor));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state_selected), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        country.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.mystryColor));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country_selected), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        postal_code.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.mystryColor));
                mobile.setHintTextColor(getResources().getColor(R.color.grey));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postal_selected), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile), null, null, null);
            }
        });
        mobile.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                /*Hint Color*/
                firstname.setHintTextColor(getResources().getColor(R.color.grey));
                lastname.setHintTextColor(getResources().getColor(R.color.grey));
                email.setHintTextColor(getResources().getColor(R.color.grey));
                password.setHintTextColor(getResources().getColor(R.color.grey));
                address.setHintTextColor(getResources().getColor(R.color.grey));
                city.setHintTextColor(getResources().getColor(R.color.grey));
                state.setHintTextColor(getResources().getColor(R.color.grey));
                country.setHintTextColor(getResources().getColor(R.color.grey));
                postal_code.setHintTextColor(getResources().getColor(R.color.grey));
                mobile.setHintTextColor(getResources().getColor(R.color.mystryColor));
                /*Drawable color change*/
                firstname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_firstname), null, null, null);
                lastname.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_lastname), null, null, null);
                email.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_email), null, null, null);
                password.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_password), null, null, null);
                address.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_address), null, null, null);
                city.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_city), null, null, null);
                state.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_state), null, null, null);
                country.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_country), null, null, null);
                postal_code.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_postalcode), null, null, null);
                mobile.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.profile_mobile_selected), null, null, null);
            }
        });
        radioButton_paypal.setTextColor(getResources().getColor(R.color.mystryColor));
        radioButton_nochoice.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButton_nochoice.isChecked()) {
                    radioButton_nochoice.setTextColor(getResources().getColor(R.color.mystryColor));
                } else {
                    radioButton_nochoice.setTextColor(getResources().getColor(R.color.mystrytextxolor));
                }
            }
        });
        radioButton_paypal.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (radioButton_paypal.isChecked()) {
                    radioButton_paypal.setTextColor(getResources().getColor(R.color.mystryColor));
                } else {
                    radioButton_paypal.setTextColor(getResources().getColor(R.color.mystrytextxolor));
                }
            }
        });
        password_visibility.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    password.setSelection(password.getText().length());
                    return true;
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    password.setSelection(password.getText().length());
                    return true;
                }
                return false;
            }
        });
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email_text = email.getText().toString().trim();
                final String postal_codetext = postal_code.getText().toString().trim();
                fname_update_string = firstname.getText().toString().trim();
                lname_update_string = lastname.getText().toString().trim();
                email_update_string = email.getText().toString().trim();
                password_update_string = password.getText().toString().trim();
                address_update_string = address.getText().toString().trim();
                city_update_string = city.getText().toString().trim();
                state_update_string = state.getText().toString().trim();
                country_update_string = country.getText().toString().trim();
                postal_update_string = postal_code.getText().toString().trim();
                mobile_update_string = mobile.getText().toString().trim();


                if ((!email.getText().toString().equals("")) && (!postal_code.getText().toString().equals("")) && (!firstname.getText().toString().equals("")) && (!lastname.getText().toString().equals("")) && (!password.getText().toString().equals("")) && (!address.getText().toString().equals("")) && (!city.getText().toString().equals("")) && (!state.getText().toString().equals("")) && (!country.getText().toString().equals("")) && (!mobile.getText().toString().equals(""))) {
                    if (postal_codetext.length() != 6) {
                        Toast.makeText(getActivity(), "Postal code must be ", Toast.LENGTH_SHORT).show();
                    } else if (mobile.getText().length() != 10) {
                        Toast.makeText(getActivity(), "Mobile number must be 10 digits long", Toast.LENGTH_SHORT).show();
                    } else {
                        progressDialog = ProgressDialog.show(getActivity(), "", "Please Wait...");
                        progressDialog.setCancelable(false);
                        RequestQueue queue = Volley.newRequestQueue(getActivity());
                        url = hostFile.UpdateUser();
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        responseFromVolly = response;
                                        System.out.println("XXX response = " + response);
                                        new UpdateProfileAsync().execute();
                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressDialog.dismiss();
                                if (error instanceof TimeoutError) {
                                    error.printStackTrace();
                                } else if (error instanceof NoConnectionError) {
                                    error.printStackTrace();
                                } else if (error instanceof AuthFailureError) {
                                    error.printStackTrace();
                                } else if (error instanceof ServerError) {
                                    error.printStackTrace();
                                } else if (error instanceof NetworkError) {
                                    error.printStackTrace();
                                } else if (error instanceof ParseError) {
                                    error.printStackTrace();
                                }
                            }
                        }) {
                            @Override
                            public Map<String, String> getParams() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                params.put("id", user_id_db);
                                params.put("fname", fname_update_string);
                                params.put("lname", lname_update_string);
                                params.put("password", password_update_string);
                                params.put("email", email_db);
                                params.put("location", address_update_string);
                                params.put("mobileno", mobile_update_string);
                                params.put("city", city_update_string);
                                params.put("pincode", postal_codetext);
                                params.put("state", state_update_string);
                                params.put("country", country_update_string);
                                return params;
                            }
                        };
                        queue.add(stringRequest);
                    }
                } else {
                    Toast.makeText(getActivity(), "All Fields are compulsory", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void checkForCameraPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
                AlertDialog.Builder alertBuilder = new AlertDialog.Builder(getActivity());
                alertBuilder.setCancelable(true);
                alertBuilder.setTitle(R.string.location_permission);
                alertBuilder.setMessage("Location Access is compulsory to auto-detect Address!");
                alertBuilder.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                6);
                    }
                });

                AlertDialog alert = alertBuilder.create();
                alert.show();
            } else {
                // No explanation needed, we can request the permission.
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        6);


            }
        } else {
            getAddress();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 6) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getAddress();
            } else {
                Toast.makeText(getActivity(), "UnGranted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void showAlertforgps() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        alertDialog.setTitle(R.string.gps_internet);
        alertDialog.setMessage("You need to connect to GPS for accessing your current location.");
        alertDialog.setPositiveButton("Enable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                getActivity().startActivity(i);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    public class FetchCordinates extends AsyncTask<String, Integer, String> {
        ProgressDialog progDailog = null;

        public double lati = 0.0;
        public double longi = 0.0;
        public LocationManager mLocationManager;
        public mLocationListener mListener;

        @Override
        protected void onPreExecute() {

            mListener = new mLocationListener();
            mLocationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

            mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mListener);
            progDailog = new ProgressDialog(getActivity());
            progDailog.setMessage("Please Wait while we Fetch your Location...");
            progDailog.setIndeterminate(true);
            progDailog.setCancelable(false);
            progDailog.show();

        }

        @Override
        protected void onCancelled() {
            System.out.println("Cancelled by user!");
            progDailog.dismiss();
            mLocationManager.removeUpdates(mListener);
        }

        @Override
        protected void onPostExecute(String result) {
            progDailog.dismiss();

            Geocoder geo = new Geocoder(getActivity(), Locale.getDefault());
            List<Address> add = new ArrayList<>();
            try {
                add = geo.getFromLocation(lati, longi, 1);
                address.setText(add.get(0).getAddressLine(0) + " " + add.get(0).getAddressLine(1));
                city.setText(add.get(0).getSubAdminArea());
                state.setText(add.get(0).getAdminArea());
                country.setText(add.get(0).getCountryName());
                postal_code.setText(add.get(0).getPostalCode());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub

            while (this.lati == 0.0) {

            }
            return null;
        }

        public class mLocationListener implements LocationListener {

            @Override
            public void onLocationChanged(Location location) {
                try {
                    lati = location.getLatitude();
                    longi = location.getLongitude();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProviderDisabled(String provider) {
                Log.i("OnProviderDisabled", "OnProviderDisabled");
            }

            @Override
            public void onProviderEnabled(String provider) {
                Log.i("onProviderEnabled", "onProviderEnabled");
            }

            @Override
            public void onStatusChanged(String provider, int status,
                                        Bundle extras) {
                Log.i("onStatusChanged", "onStatusChanged");
            }
        }
    }


    public class UpdateProfileAsync extends AsyncTask<Void, Void, Void> {
        int code;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responseFromVolly);
                code = jsonObject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            if (code == 100) {
                Toast.makeText(getActivity(), "Unable to update", Toast.LENGTH_SHORT).show();
            } else if (code == 200) {
                Toast.makeText(getActivity(), "Updated succeessfully", Toast.LENGTH_SHORT).show();
                new Intent(getActivity(), Mystry_services.class);
            }

        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(receiver_stopservice);
        getActivity().unregisterReceiver(receiver_startservice);
    }
}