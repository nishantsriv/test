package com.buckwalk.Database;

import android.provider.ContactsContract;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Saurabh on 08-05-2017.
 */

public class LoginDataMapper {

    LoginData loginData;

    public void add_info(LoginData loginData){
        Database db = new Database();
        Map<String,String> map = new HashMap<String, String>();

        map.put("id",loginData.id);
        map.put("user_id",loginData.user_id);
        map.put("user_name",loginData.name);
        map.put("user_email",loginData.email);
        map.put("user_phone",loginData.phone);
        map.put("user_location",loginData.location);
        map.put("user_image",loginData.image);
        map.put("user_city",loginData.city);
        map.put("user_state",loginData.state);
        map.put("user_country",loginData.country);
        map.put("user_pincode",loginData.pincode);


        db.insertRow("UserLogin",map);
    }


    public LoginData getInfo(String id) {
        Database db = new Database();
        LoginData infoObj = new LoginData(db.fetchRow("UserLogin", "id", id));
        return infoObj;
    }

    public int row_count() {
        Database db=new Database();
        long count=db.rowCount("UserLogin");
        return (int) count;
    }


}
