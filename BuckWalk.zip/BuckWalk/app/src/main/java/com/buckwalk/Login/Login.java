package com.buckwalk.Login;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Home.Home;
import com.buckwalk.Host.HostFile;
import com.buckwalk.R;
import com.buckwalk.Register.Register;
import com.nostra13.universalimageloader.utils.L;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class Login extends AppCompatActivity {


    TextView login_textview;
    TextView to_textview;
    TextView account_textview;
    TextView forget_textview;
    EditText email_edittext;
    EditText password_edittext;
    Button login_button;
    Button register_button;

    String email_string;
    String password_string;
    String email_validation = "[a-zA-Z0-9._-]+\\@+[a-zA-Z0-9._-]+\\.+[a-z]+";
    String url;
    String responseFromVolly,responseFromVolly_fcm;

    ProgressDialog progressDialog;

    Database db = new Database();
    UserTable table = new UserTable();
    LoginData loginData = new LoginData();
    LoginDataMapper loginDataMapper = new LoginDataMapper();

    HostFile hostFile = new HostFile();
    //Dialog widget
    EditText editText_forget_email;
    Button button_forget;
    String response_url_forget;
    ProgressDialog progressDialog_forget;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login_textview = (TextView) findViewById(R.id.login_login_textview);
        to_textview = (TextView) findViewById(R.id.login_to_textview);
        account_textview = (TextView) findViewById(R.id.login_account_textview);
        forget_textview = (TextView) findViewById(R.id.login_forgot_textview);
        email_edittext = (EditText) findViewById(R.id.login_email_edittext);
        password_edittext = (EditText) findViewById(R.id.login_password_edittext);
        login_button = (Button) findViewById(R.id.login_login_button);
        register_button = (Button) findViewById(R.id.login_register_button);

        Typeface lato_regular = Typeface.createFromAsset(getAssets(), "fonts/lato_regular.ttf");
        login_textview.setTypeface(lato_regular);
        to_textview.setTypeface(lato_regular);
        account_textview.setTypeface(lato_regular);
        forget_textview.setTypeface(lato_regular);
        forget_textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogbox();
            }
        });
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email_string = email_edittext.getText().toString().trim();
                password_string = password_edittext.getText().toString().trim();

                if (!email_string.matches(email_validation)) {
                    email_edittext.setError("Enter valid email");
                } else if (email_string.isEmpty()) {
                    email_edittext.setError("Please enter email");
                } else if (password_string.isEmpty()) {
                    password_edittext.setError("Please enter password");
                } else {

                    progressDialog = ProgressDialog.show(Login.this, "", "Please Wait...");
                    RequestQueue queue = Volley.newRequestQueue(Login.this);
                    url = hostFile.loginUser();
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    responseFromVolly = response;
                                    System.out.println("XXX response = " + response);
                                    new LoginAsync().execute();
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                            if (error instanceof TimeoutError) {
                                error.printStackTrace();
                            } else if (error instanceof NoConnectionError) {
                                error.printStackTrace();
                            } else if (error instanceof AuthFailureError) {
                                error.printStackTrace();
                            } else if (error instanceof ServerError) {
                                error.printStackTrace();
                            } else if (error instanceof NetworkError) {
                                error.printStackTrace();
                            } else if (error instanceof ParseError) {
                                error.printStackTrace();
                            }
                        }
                    }) {
                        @Override
                        public Map<String, String> getParams() throws AuthFailureError {
                            HashMap<String, String> params = new HashMap<String, String>();
                            params.put("email", email_string);
                            params.put("password", password_string);
                            return params;
                        }
                    };
                    queue.add(stringRequest);
                }
            }
        });


        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, Register.class);
                startActivity(i);
            }
        });
    }

    private void dialogbox() {

        dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.login_dialog);
        editText_forget_email = (EditText) dialog.findViewById(R.id.forget_email_edittext);
        button_forget = (Button) dialog.findViewById(R.id.forget_submit_button);
        button_forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(editText_forget_email.getText().toString())) {
                    Toast.makeText(Login.this, "Please enter email address", Toast.LENGTH_SHORT).show();
                } else if (!editText_forget_email.getText().toString().matches(email_validation)) {
                    Toast.makeText(Login.this, "Please enter valid email", Toast.LENGTH_SHORT).show();
                } else {
                    progressDialog_forget = new ProgressDialog(Login.this);
                    progressDialog_forget.setMessage("Sending Request...");
                    progressDialog_forget.show();
                    String forget_url = "http://gaganvats.com/Api/forget_password.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui";
                    RequestQueue queue = Volley.newRequestQueue(Login.this);
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, forget_url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            response_url_forget = response;
                            new Asyncforget().execute();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog_forget.dismiss();
                            if (error instanceof TimeoutError) {
                                error.printStackTrace();
                            } else if (error instanceof NoConnectionError) {
                                error.printStackTrace();
                            } else if (error instanceof AuthFailureError) {
                                error.printStackTrace();
                            } else if (error instanceof ServerError) {
                                error.printStackTrace();
                            } else if (error instanceof NetworkError) {
                                error.printStackTrace();
                            } else if (error instanceof ParseError) {
                                error.printStackTrace();
                            }

                        }
                    }) {
                        @Override
                        public Map<String, String> getParams() throws AuthFailureError {
                            HashMap<String, String> params = new HashMap<String, String>();
                            params.put("email", editText_forget_email.getText().toString());
                            return params;
                        }


                    };
                    queue.add(stringRequest);
                }
            }
        });
        dialog.show();

    }


    public class LoginAsync extends AsyncTask<Void, Void, Void> {

        int code;
        String message;

        String id, name, email, mobile, location, image, city, state, country, pincode;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        @Override
        protected Void doInBackground(Void... params) {

            try {
                JSONObject reader = new JSONObject(responseFromVolly);
                JSONObject response = reader.getJSONObject("meta");
                code = response.getInt("status");
                message = response.getString("msg");

                JSONObject data = reader.getJSONObject("data");
                id = data.getString("id");
                name = data.getString("name");
                email = data.getString("emailid");
                mobile = data.getString("mobile");
                location = data.getString("location");
                image = data.getString("image");
                city = data.getString("city");
                state = data.getString("state");
                country = data.getString("country");
                pincode = data.getString("pincode");

                System.out.println("XXX id = " + id);
                System.out.println("XXX name = " + name);
                System.out.println("XXX email = " + email);
                System.out.println("XXX mobile = " + mobile);
                System.out.println("XXX location = " + location);
                System.out.println("XXX image = " + image);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (code == 200) {
                progressDialog.dismiss();
                Toast.makeText(Login.this, "Login successfully", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Login.this, Home.class);
                startActivity(i);
                finish();


                db.deleteAllRow("UserLogin");
                loginData.id = "1";
                loginData.user_id = id;
                loginData.name = name;
                loginData.email = email;
                loginData.phone = mobile;
                loginData.location = location;
                loginData.image = image;
                loginData.city = city;
                loginData.state = state;
                loginData.country = country;
                loginData.pincode = pincode;

                loginDataMapper.add_info(loginData);
                final String userid = loginDataMapper.getInfo("1").user_id;
                /*Sending FCM id*/
                final SharedPreferences preferences = getSharedPreferences("FCM_Detail", MODE_PRIVATE);
                final String fcm_id = preferences.getString("fcm_id", null);
                String url_fcm = hostFile.home_fcmid();
                if (fcm_id != null) {
                    RequestQueue queue1 = Volley.newRequestQueue(Login.this);
                    StringRequest stringRequest_fcm = new StringRequest(Request.Method.POST, url_fcm, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            responseFromVolly_fcm = response;
                            new Asyncfcm().execute();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                            if (error instanceof TimeoutError) {
                                error.printStackTrace();
                            } else if (error instanceof NoConnectionError) {
                                error.printStackTrace();
                            } else if (error instanceof AuthFailureError) {
                                error.printStackTrace();
                            } else if (error instanceof ServerError) {
                                error.printStackTrace();
                            } else if (error instanceof NetworkError) {
                                error.printStackTrace();
                            } else if (error instanceof ParseError) {
                                error.printStackTrace();
                            }
                        }
                    }) {
                        @Override
                        public Map<String, String> getParams() throws AuthFailureError {
                            HashMap<String, String> params = new HashMap<String, String>();
                            params.put("user_id", userid);
                            params.put("fcm_id", fcm_id);
                            return params;
                        }
                    };
                    queue1.add(stringRequest_fcm);
                }

            } else {
                progressDialog.dismiss();
                Toast.makeText(Login.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }

        }
    }

    class Asyncforget extends AsyncTask<Void, Void, Void> {

        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(response_url_forget);
                status = jsonObject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            progressDialog_forget.dismiss();

            if (status == 401) {
                Toast.makeText(Login.this, "Email id not registered", Toast.LENGTH_SHORT).show();
            } else if (status == 200) {
                dialog.dismiss();
                Toast.makeText(Login.this, "Email send to registered email address ", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Login.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        }
    }
    public class Asyncfcm extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responseFromVolly_fcm);
                status = jsonObject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (status == 200) {
                Log.d("TEST_FCMHOME", "successfully submitted");
            } else {
                Log.d("TEST_FCMHOME", "successfully not submitted" + status);
            }
        }
    }
}
