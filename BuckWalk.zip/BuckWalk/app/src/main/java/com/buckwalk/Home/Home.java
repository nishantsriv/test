package com.buckwalk.Home;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.speech.tts.Voice;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Drawer.DrawerFragment;
import com.buckwalk.ErrandListDataObject;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.Mystry_services;
import com.buckwalk.Mystry.Shoplog.Adapter_mystry;
import com.buckwalk.R;
import com.buckwalk.Register.Register;
import com.buckwalk.Request_errand;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollView;
import com.github.ksoichiro.android.observablescrollview.ObservableScrollViewCallbacks;
import com.github.ksoichiro.android.observablescrollview.ScrollState;
import com.nineoldandroids.view.ViewHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.view.View.GONE;

public class Home extends AppCompatActivity implements ObservableScrollViewCallbacks {

    Toolbar toolbar;
    Spinner toolbar_spinner;
    ImageView drawer_icon;
    DrawerLayout drawerLayout;
    ImageView toolbar_search;
    RecyclerView home_post_recycler_view;
    StaggeredGridLayoutManager layoutManager;
    PostRecyclerAdapter postRecyclerAdapter;
    LinearLayout mystry_layout;
    NestedScrollView scrollView;
    LinearLayout homeMenuLayout;
    LinearLayout request_errand;
    ProgressBar progressBar;
    LinearLayout emptyview;
    ProgressDialog progressDialog;
    String[] city = {"Gurugram", "Jaipur", "Delhi"};
    DrawerFragment drawerFragment;

    Database db = new Database();
    UserTable table = new UserTable();
    LoginData loginData = new LoginData();
    LoginDataMapper loginDataMapper = new LoginDataMapper();

    HostFile hostFile = new HostFile();
    String url, responseFromVolly, responseFromVolly_fcm;
    public static RequestQueue queue;
    public static StringRequest stringRequest;
    int code;
    String message, id, errand_id, customer_name, service_type, pickup_loc, drop_loc, errand_savedby, proposed_amount, what_to_do, cust_mob,
            errand_status, saved_time, userid;

    ArrayList<ErrandListDataObject> errandList = new ArrayList<ErrandListDataObject>();

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        loginData = new LoginData();
        loginDataMapper = new LoginDataMapper();
        loginData = loginDataMapper.getInfo("1");
        userid = loginData.user_id;

        emptyview = (LinearLayout) findViewById(R.id.home_recycler_emptyview);
        progressBar = (ProgressBar) findViewById(R.id.home_progressbar);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawer_icon = (ImageView) toolbar.findViewById(R.id.toolbar_drawer_icon);
        toolbar_spinner = (Spinner) toolbar.findViewById(R.id.toolbar_spinner);
        toolbar_search = (ImageView) toolbar.findViewById(R.id.toolbar_search_icon);
        homeMenuLayout = (LinearLayout) findViewById(R.id.home_menu_layout);
        scrollView = (NestedScrollView) findViewById(R.id.homeObservableScrollview);
//        scrollView.setScrollViewCallbacks(this);
        drawerLayout = (DrawerLayout) findViewById(R.id.home_drawer_layout);
        mystry_layout = (LinearLayout) findViewById(R.id.home_mystry_layout);
        request_errand = (LinearLayout) findViewById(R.id.home_request_errand);
        home_post_recycler_view = (RecyclerView) findViewById(R.id.home_posted_recyclerview);
        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);
        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);


        queue = Volley.newRequestQueue(Home.this);
        url = hostFile.errandreqList();
        stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        responseFromVolly = response;
                        System.out.println("XXX response = " + response);

                        new ErrandRequestList().execute();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(GONE);

                if (error instanceof TimeoutError) {
                    Toast.makeText(Home.this, "TimeoutError", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    Toast.makeText(Home.this, "NoConnectionError", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    Toast.makeText(Home.this, "ServerError", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    Toast.makeText(Home.this, "NetworkError", Toast.LENGTH_SHORT).show();
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }
            }
        });
        queue.add(stringRequest);


        home_post_recycler_view.setNestedScrollingEnabled(false);
        layoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL);
        home_post_recycler_view.setLayoutManager(layoutManager);
        postRecyclerAdapter = new PostRecyclerAdapter(Home.this, errandList);


        mystry_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this, Mystry_services.class);
                startActivity(i);
            }
        });

        request_errand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this, Request_errand.class);
                startActivity(i);
            }
        });


    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
//        onScrollChanged(scrollView.getCurrentScrollY(), false, false);
    }

    @Override
    public void onScrollChanged(int scrollY, boolean firstScroll, boolean dragging) {
        ViewHelper.setTranslationY(homeMenuLayout, scrollY / 2);
    }

    @Override
    public void onDownMotionEvent() {

    }

    @Override
    public void onUpOrCancelMotionEvent(ScrollState scrollState) {

    }


    public class ErrandRequestList extends AsyncTask<Void, Void, Void> {
        JSONArray data;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            errandList.clear();
            try {

                JSONObject reader = new JSONObject(responseFromVolly);
                JSONObject meta = reader.getJSONObject("meta");

                code = meta.getInt("status");
                message = meta.getString("msg");

                if (code == 200) {

                    data = reader.getJSONArray("data");

                    for (int i = 0; i < data.length(); i++) {
                        JSONObject data_obj = data.getJSONObject(i);

                        id = data_obj.getString("id");
                        errand_id = data_obj.getString("errands_id");
                        customer_name = data_obj.getString("customer_name").replace("%20", " ");
                        service_type = data_obj.getString("service_type");
                        pickup_loc = data_obj.getString("pick_location");
                        drop_loc = data_obj.getString("drop_location");
                        errand_savedby = data_obj.getString("errands_savedby");
                        proposed_amount = data_obj.getString("proposed_amount");
                        what_to_do = data_obj.getString("errand_comment");
                        cust_mob = data_obj.getString("customer_mob");
                        errand_status = data_obj.getString("errands_status");
                        saved_time = data_obj.getString("errands_status");

                        errandList.add(new ErrandListDataObject(id, errand_id, customer_name, service_type, pickup_loc, drop_loc,
                                errand_savedby, proposed_amount, what_to_do, cust_mob, errand_status, saved_time));
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            if (code == 200) {
                progressBar.setVisibility(GONE);
                home_post_recycler_view.setAdapter(postRecyclerAdapter);
                if (data == null) {
                    emptyview.setVisibility(View.VISIBLE);
                    home_post_recycler_view.setVisibility(GONE);
                } else {
                    emptyview.setVisibility(GONE);
                    home_post_recycler_view.setVisibility(View.VISIBLE);
                }
            } else {
                progressBar.setVisibility(GONE);
                home_post_recycler_view.setVisibility(GONE);
                emptyview.setVisibility(View.VISIBLE);
            }

        }
    }
}
