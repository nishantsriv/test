package com.buckwalk;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by SAMSUNG on 5/20/2017.
 */

public class ErrandsViewpagerAdapter extends FragmentStatePagerAdapter {
    Fragment frag;
    public ErrandsViewpagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        if(position==0)
        {
            frag=new Accepted();
        }
        else
        {
            frag=new Requested();
        }
        return frag;
    }

    @Override
    public int getCount() {
        return 2;
    }
}
