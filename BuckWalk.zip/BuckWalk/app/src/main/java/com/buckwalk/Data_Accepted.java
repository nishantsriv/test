package com.buckwalk;

/**
 * Created by SAMSUNG on 5/20/2017.
 */

public class Data_Accepted {
    String id ,errands_id,customer_name,service_type,pick_location,drop_location,errands_savedby,proposed_amount,customer_mob,errands_status,saved_time,valid,name,mobile;

    public Data_Accepted(String id, String errands_id, String customer_name, String service_type, String pick_location, String drop_location, String errands_savedby, String proposed_amount, String customer_mob, String errands_status, String saved_time, String valid, String name, String mobile) {
        this.id = id;
        this.errands_id = errands_id;
        this.customer_name = customer_name;
        this.service_type = service_type;
        this.pick_location = pick_location;
        this.drop_location = drop_location;
        this.errands_savedby = errands_savedby;
        this.proposed_amount = proposed_amount;
        this.customer_mob = customer_mob;
        this.errands_status = errands_status;
        this.saved_time = saved_time;
        this.valid = valid;
        this.name = name;
        this.mobile = mobile;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getErrands_id() {
        return errands_id;
    }

    public void setErrands_id(String errands_id) {
        this.errands_id = errands_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getPick_location() {
        return pick_location;
    }

    public void setPick_location(String pick_location) {
        this.pick_location = pick_location;
    }

    public String getDrop_location() {
        return drop_location;
    }

    public void setDrop_location(String drop_location) {
        this.drop_location = drop_location;
    }

    public String getErrands_savedby() {
        return errands_savedby;
    }

    public void setErrands_savedby(String errands_savedby) {
        this.errands_savedby = errands_savedby;
    }

    public String getProposed_amount() {
        return proposed_amount;
    }

    public void setProposed_amount(String proposed_amount) {
        this.proposed_amount = proposed_amount;
    }

    public String getCustomer_mob() {
        return customer_mob;
    }

    public void setCustomer_mob(String customer_mob) {
        this.customer_mob = customer_mob;
    }

    public String getErrands_status() {
        return errands_status;
    }

    public void setErrands_status(String errands_status) {
        this.errands_status = errands_status;
    }

    public String getSaved_time() {
        return saved_time;
    }

    public void setSaved_time(String saved_time) {
        this.saved_time = saved_time;
    }

    public String getValid() {
        return valid;
    }

    public void setValid(String valid) {
        this.valid = valid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
