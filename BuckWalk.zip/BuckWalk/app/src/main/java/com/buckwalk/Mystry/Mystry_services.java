package com.buckwalk.Mystry;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.buckwalk.Drawer.DrawerFragment;
import com.buckwalk.Mystry.JobBoard.JobBoard_Fragment;
import com.buckwalk.Mystry.Profile.Profile_Fragment;
import com.buckwalk.R;
import com.buckwalk.Mystry.Shoplog.Shoplog;

public class Mystry_services extends AppCompatActivity {

    Toolbar toolbar;
    Spinner toolbar_spinner;
    DrawerLayout drawerLayout;
    ImageView drawer_icon;
    ImageView toolbar_search;
    DrawerFragment drawerFragment;
    String[] city = {"Gurugram", "Jaipur", "Delhi"};

    public static ViewPager viewPager;
    public static TabLayout tabLayout;
    public static ViewPagerAdapter pagerAdapter;
    TextView tab1_title, tab2_title, tab3_title;
    ImageView img3, img2, img1;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mystry_services);
        viewPager = (ViewPager) findViewById(R.id.mystry_viewpager);
        tabLayout = (TabLayout) findViewById(R.id.mystry_tablayout);
        drawerLayout = (DrawerLayout) findViewById(R.id.mystry_drawer_layout);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawer_icon = (ImageView) findViewById(R.id.toolbar_drawer_icon);

        toolbar_spinner = (Spinner) toolbar.findViewById(R.id.toolbar_spinner);
        toolbar_search = (ImageView) toolbar.findViewById(R.id.toolbar_search_icon);

        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);

        drawerFragment = new DrawerFragment();
        if (null == savedInstanceState) {
            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.drawer_fragment_left, drawerFragment, "drawer_frag");
            transaction.commit();
        }

        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);



        /*Tab Setup*/

        pagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        pagerAdapter.addfragment(new Shoplog());
        pagerAdapter.addfragment(new JobBoard_Fragment());
        pagerAdapter.addfragment(new Profile_Fragment());
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.setTabTextColors(Color.LTGRAY, getResources().getColor(R.color.mystryColor));
        setupTabIcons();
        /*Divider Setup*/
        LinearLayout linearLayout = (LinearLayout) tabLayout.getChildAt(0);
        linearLayout.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.LTGRAY);
        drawable.setSize(4, 1);
        linearLayout.setDividerPadding(30);
        linearLayout.setDividerDrawable(drawable);
    }

    public void setupTabIcons() {
        tabLayout.getTabAt(0).setCustomView(R.layout.custom_tab_title);
        tabLayout.getTabAt(1).setCustomView(R.layout.custom_tab_title);
        tabLayout.getTabAt(2).setCustomView(R.layout.custom_tab_title);
        View tab1_view = tabLayout.getTabAt(0).getCustomView();
        View tab2_view = tabLayout.getTabAt(1).getCustomView();
        View tab3_view = tabLayout.getTabAt(2).getCustomView();
        tab1_title = (TextView) tab1_view.findViewById(R.id.mystry_texttab);
        img1 = (ImageView) tab1_view.findViewById(R.id.mystry_imagetab);
        tab2_title = (TextView) tab2_view.findViewById(R.id.mystry_texttab);
        img2 = (ImageView) tab2_view.findViewById(R.id.mystry_imagetab);
        tab3_title = (TextView) tab3_view.findViewById(R.id.mystry_texttab);
        img3 = (ImageView) tab3_view.findViewById(R.id.mystry_imagetab);
        tab1_title.setText("Shop Log");
        tab1_title.setTextColor(getResources().getColor(R.color.mystryColor));
        img1.setImageResource(R.drawable.mystry_shoplog);
        tab2_title.setText("Job Board");
        tab1_title.setTextColor(Color.GRAY);
        img2.setImageResource(R.drawable.mystry_job);
        tab3_title.setText("Profile");
        tab1_title.setTextColor(Color.GRAY);
        img3.setImageResource(R.drawable.mystry_profile);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab == tabLayout.getTabAt(0)) {
                    tab1_title.setTextColor(getResources().getColor(R.color.mystryColor));
                    img1.setImageResource(R.drawable.mystry_shoplog);
                } else if (tab == tabLayout.getTabAt(1)) {
                    img2.setImageResource(R.drawable.mystry_jobcomp);
                    tab2_title.setTextColor(getResources().getColor(R.color.mystryColor));
                } else if (tab == tabLayout.getTabAt(2)) {
                    img3.setImageResource(R.drawable.mystry_profilecomp);
                    tab3_title.setTextColor(getResources().getColor(R.color.mystryColor));
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                if (tab == tabLayout.getTabAt(0)) {
                    tab1_title.setTextColor(Color.GRAY);
                    img1.setImageResource(R.drawable.mystry_shoplogcomp);
                } else if (tab == tabLayout.getTabAt(1)) {
                    img2.setImageResource(R.drawable.mystry_job);
                    tab2_title.setTextColor(Color.GRAY);
                } else if (tab == tabLayout.getTabAt(2)) {
                    img3.setImageResource(R.drawable.mystry_profile);
                    tab3_title.setTextColor(Color.GRAY);
                }
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }
}
