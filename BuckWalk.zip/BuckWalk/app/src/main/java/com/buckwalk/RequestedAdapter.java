package com.buckwalk;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by SAMSUNG on 5/20/2017.
 */

public class RequestedAdapter extends RecyclerView.Adapter<RequestedAdapter.Holder> {
    private Context context;
    private ArrayList<Data_Requested> allrequests;
    private LayoutInflater layoutInflater;

    public RequestedAdapter(Context context,ArrayList<Data_Requested> allrequests1) {
        this.context = context;
     this.allrequests=allrequests1;
        this.layoutInflater=LayoutInflater.from(context);
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
      View v=layoutInflater.inflate(R.layout.model_errand_all_requests,parent,false);
        Holder holder=new Holder(v);
        return  holder;
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        holder.comp_name.setText(allrequests.get(position).getName());
        holder.location.setText(allrequests.get(position).getDrop_location());
        holder.date_to.setText(allrequests.get(position).getValid());
        holder.amount.setText(allrequests.get(position).getProposed_amount());

    }

    @Override
    public int getItemCount() {
        return allrequests.size();
    }


    public class Holder  extends RecyclerView.ViewHolder{
        TextView comp_name,location,date_from,date_to,amount;
        public Holder(View itemView) {
            super(itemView);
            comp_name=(TextView)itemView.findViewById(R.id.allrequests_companyname);
            location=(TextView)itemView.findViewById(R.id.allrequests_location);
            date_from=(TextView)itemView.findViewById(R.id.allrequests_datefrom);
            date_to=(TextView)itemView.findViewById(R.id.allrequests_dateto);
            amount=(TextView)itemView.findViewById(R.id.allrequests_amount);

        }
    }
}
