package com.buckwalk;

/**
 * Created by SAMSUNG on 5/19/2017.
 */

public class Data_Object {
    String id, customer_name, service_type,pick_location,drop_location,proposed_amount,errand_comment,customer_mob,time,saved_time,errands_id, errands_savedby, errands_status;

    public Data_Object(String id, String customer_name, String service_type, String pick_location, String drop_location, String proposed_amount, String errand_comment, String customer_mob, String time, String saved_time, String errands_id, String errands_savedby, String errands_status) {
        this.id = id;
        this.customer_name = customer_name;
        this.service_type = service_type;
        this.pick_location = pick_location;
        this.drop_location = drop_location;
        this.proposed_amount = proposed_amount;
        this.errand_comment = errand_comment;
        this.customer_mob = customer_mob;
        this.time = time;
        this.saved_time = saved_time;
        this.errands_id = errands_id;
        this.errands_savedby = errands_savedby;
        this.errands_status = errands_status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getPick_location() {
        return pick_location;
    }

    public void setPick_location(String pick_location) {
        this.pick_location = pick_location;
    }

    public String getDrop_location() {
        return drop_location;
    }

    public void setDrop_location(String drop_location) {
        this.drop_location = drop_location;
    }

    public String getProposed_amount() {
        return proposed_amount;
    }

    public void setProposed_amount(String proposed_amount) {
        this.proposed_amount = proposed_amount;
    }

    public String getErrand_comment() {
        return errand_comment;
    }

    public void setErrand_comment(String errand_comment) {
        this.errand_comment = errand_comment;
    }

    public String getCustomer_mob() {
        return customer_mob;
    }

    public void setCustomer_mob(String customer_mob) {
        this.customer_mob = customer_mob;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSaved_time() {
        return saved_time;
    }

    public void setSaved_time(String saved_time) {
        this.saved_time = saved_time;
    }

    public String getErrands_id() {
        return errands_id;
    }

    public void setErrands_id(String errands_id) {
        this.errands_id = errands_id;
    }

    public String getErrands_savedby() {
        return errands_savedby;
    }

    public void setErrands_savedby(String errands_savedby) {
        this.errands_savedby = errands_savedby;
    }

    public String getErrands_status() {
        return errands_status;
    }

    public void setErrands_status(String errands_status) {
        this.errands_status = errands_status;
    }
}
