package com.buckwalk.Mystry.JobBoard;


import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.Shoplog.Data_shoplog;
import com.buckwalk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class JobBoard_Fragment extends Fragment {
    public static LinearLayout emptytextview;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private Adapter_jobboard adapter_jobboard;
    private ArrayAdapter<CharSequence> adapter;
    private Spinner spinner;
    public ProgressDialog progressDialog;
    private ArrayList<Data_shoplog> pending_arraylist, accepted_arraylist, processing_arraylist;
    private BroadcastReceiver receiver_showpd, receiver_dismisspd;
    private String responsefromVolley;
    private LoginDataMapper loginDataMapper;
    private LoginData loginData;
    public static RequestQueue requestQueue;
    public static StringRequest stringRequest;
    private HostFile hostFile;

    public JobBoard_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_job_board_, container, false);
        hostFile = new HostFile();
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        pending_arraylist = new ArrayList<>();
        accepted_arraylist = new ArrayList<>();
        processing_arraylist = new ArrayList<>();
        /*Spinner*/
        emptytextview = (LinearLayout) view.findViewById(R.id.jobboard_emptytextView);
        spinner = (Spinner) view.findViewById(R.id.jobboard_spinner);
        adapter = ArrayAdapter.createFromResource(getActivity(), R.array.job_status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        loginData = new LoginData();
        loginDataMapper = new LoginDataMapper();
        loginData = loginDataMapper.getInfo("1");
        String userid = loginData.user_id;
        /*RecyclerView*/
        recyclerView = (RecyclerView) view.findViewById(R.id.jobboard_recyclerview);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter_jobboard);
        final String url = hostFile.job_board() + userid;
        /*final String url = "http://gaganvats.com/Api/user_allaudit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui&user_id=" + userid;*/
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                responsefromVolley = response;
                Log.d("TEST_JOBB", response + "\n" + url);
                new Asyncvolley_shop().execute();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                if (error instanceof TimeoutError) {
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }
            }
        });
        requestQueue.add(stringRequest);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getSelectedItem().equals("Processing")) {
                    adapter_jobboard = new Adapter_jobboard(processing_arraylist, getActivity());
                    recyclerView.setAdapter(adapter_jobboard);
                } else if (parent.getSelectedItem().equals("Pending")) {
                    adapter_jobboard = new Adapter_jobboard(pending_arraylist, getActivity());
                    recyclerView.setAdapter(adapter_jobboard);
                } else if (parent.getSelectedItem().equals("Completed")) {
                    adapter_jobboard = new Adapter_jobboard(accepted_arraylist, getActivity());
                    recyclerView.setAdapter(adapter_jobboard);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return view;
    }

    class Asyncvolley_shop extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            progressDialog.dismiss();
            pending_arraylist.clear();
            processing_arraylist.clear();
            accepted_arraylist.clear();
            try {
                JSONObject jsonObject = new JSONObject(responsefromVolley);
                JSONObject object_meta = jsonObject.getJSONObject("meta");
                status = object_meta.getInt("status");
                JSONArray array_data = jsonObject.getJSONArray("data");
                for (int i = 0; i < array_data.length(); i++) {
                    JSONObject jsonObject1 = array_data.getJSONObject(i);
                    String shop_id = jsonObject1.getString("shop_id");
                    String shop_due_date = jsonObject1.getString("shop_due_date");
                    String survey_submit_date = jsonObject1.getString("survey_submit_date");
                    String dont_shop_before_date = jsonObject1.getString("dont_shop_before_date");
                    String address = jsonObject1.getString("address");
                    String shop_fees = jsonObject1.getString("shop_fees");
                    String shop_rtg = jsonObject1.getString("shop_rtg");
                    String audit_status = jsonObject1.getString("audit_status");
                    switch (audit_status) {
                        case "3":
                            processing_arraylist.add(new Data_shoplog(shop_id, shop_due_date, survey_submit_date, dont_shop_before_date, address, shop_fees, shop_rtg, audit_status));
                            break;
                        case "2":
                            pending_arraylist.add(new Data_shoplog(shop_id, shop_due_date, survey_submit_date, dont_shop_before_date, address, shop_fees, shop_rtg, audit_status));

                            break;
                        case "4":
                            accepted_arraylist.add(new Data_shoplog(shop_id, shop_due_date, survey_submit_date, dont_shop_before_date, address, shop_fees, shop_rtg, audit_status));
                            break;
                    }

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (status == 200) {
                if (spinner.getSelectedItem().equals("Pending")) {
                    recyclerView.setAdapter(new Adapter_jobboard(pending_arraylist, getActivity()));
                } else if (spinner.getSelectedItem().equals("Processing")) {
                    recyclerView.setAdapter(new Adapter_jobboard(processing_arraylist, getActivity()));
                } else if (spinner.getSelectedItem().equals("Completed")) {
                    recyclerView.setAdapter(new Adapter_jobboard(accepted_arraylist, getActivity()));
                }

            } else if (status == 401) {
                emptytextview.setVisibility(View.VISIBLE);
            } else {

            }
        }
    }


}