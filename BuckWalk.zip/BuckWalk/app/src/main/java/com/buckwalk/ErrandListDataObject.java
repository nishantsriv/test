package com.buckwalk;

/**
 * Created by Saurabh on 18-05-2017.
 */

public class ErrandListDataObject {

    public String id,errand_id,customer_name,service_type,pickup_loc,drop_loc,errand_savedby,proposed_amount,what_to_do
            ,cust_mob,errand_status,saved_time;


    public ErrandListDataObject(String id, String errand_id, String customer_name, String service_type, String pickup_loc, String drop_loc,
                                String errand_savedby, String proposed_amount, String what_to_do, String cust_mob, String errand_status, String saved_time) {
        this.id = id;
        this.errand_id = errand_id;
        this.customer_name = customer_name;
        this.service_type = service_type;
        this.pickup_loc = pickup_loc;
        this.drop_loc = drop_loc;
        this.errand_savedby = errand_savedby;
        this.proposed_amount = proposed_amount;
        this.what_to_do = what_to_do;
        this.cust_mob = cust_mob;
        this.errand_status = errand_status;
        this.saved_time = saved_time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getErrand_id() {
        return errand_id;
    }

    public void setErrand_id(String errand_id) {
        this.errand_id = errand_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getPickup_loc() {
        return pickup_loc;
    }

    public void setPickup_loc(String pickup_loc) {
        this.pickup_loc = pickup_loc;
    }

    public String getDrop_loc() {
        return drop_loc;
    }

    public void setDrop_loc(String drop_loc) {
        this.drop_loc = drop_loc;
    }

    public String getErrand_savedby() {
        return errand_savedby;
    }

    public void setErrand_savedby(String errand_savedby) {
        this.errand_savedby = errand_savedby;
    }

    public String getProposed_amount() {
        return proposed_amount;
    }

    public void setProposed_amount(String proposed_amount) {
        this.proposed_amount = proposed_amount;
    }

    public String getWhat_to_do() {
        return what_to_do;
    }

    public void setWhat_to_do(String what_to_do) {
        this.what_to_do = what_to_do;
    }

    public String getCust_mob() {
        return cust_mob;
    }

    public void setCust_mob(String cust_mob) {
        this.cust_mob = cust_mob;
    }

    public String getErrand_status() {
        return errand_status;
    }

    public void setErrand_status(String errand_status) {
        this.errand_status = errand_status;
    }

    public String getSaved_time() {
        return saved_time;
    }

    public void setSaved_time(String saved_time) {
        this.saved_time = saved_time;
    }
}
