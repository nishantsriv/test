package com.buckwalk.Database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Saurabh on 08-05-2017.
 */

public class Database {

    private String sqlite_db_name = "buckwalk_db";
    private String package_name = "com.buckwalk";

    public long count;

    public SQLiteDatabase connectSQLite() {
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase("/data/data/"
                + this.package_name + "/" + this.sqlite_db_name, null);
        return db;
    }

    public boolean dataExists(String table_name) {
        SQLiteDatabase db1 = null;
        SQLiteStatement statement = null;
        try {
            db1 = this.connectSQLite();
            String sql = "SELECT COUNT(*) FROM " + table_name;
            statement = db1.compileStatement(sql);
            count = statement.simpleQueryForLong();
            return count > 0;
        } catch (Exception e) {
            return false;
        } finally {
            statement.close();
            db1.close();
        }
    }

    public boolean createTableIfNotExists(String table_name, String columns[]) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            String columnString = "";
            for (String string : columns) {
                columnString = columnString + string + ",";
            }
            columnString = columnString.substring(0, columnString.length() - 1);
            String query = "CREATE TABLE IF NOT EXISTS " + table_name + " ("
                    + columnString + ");";
            db.execSQL(query);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public Map<String, String> fetchRow(String table_name, String column_name,
                                        String column_value) {
        SQLiteDatabase sql_db = null;
        Cursor c = null;
        Map<String, String> table_row = new HashMap<String, String>();
        try {
            sql_db = this.connectSQLite();
            String query;
            if (column_name != null) {
                query = "SELECT * FROM " + table_name + " WHERE " + column_name
                        + "=" + column_value;
            } else {
                query = "SELECT * FROM " + table_name;
            }

            System.out.println(query);
            c = sql_db.rawQuery(query, null);
            c.moveToFirst();
            int columnCount = c.getColumnCount();
            int i = 0;
            for (i = 0; i < columnCount; i++) {
                table_row.put(c.getColumnName(i), c.getString(i));
            }
            return table_row;
        } catch (Exception e) {
            e.printStackTrace();
            return table_row;
        } finally {
            c.close();
            sql_db.close();
        }
    }

    public List<Map<String, String>> fetchAllRows(String table_name) {
        SQLiteDatabase sql_db = null;
        Cursor c = null;
        List<Map<String, String>> table_rows = new ArrayList<Map<String, String>>();
        try {
            sql_db = this.connectSQLite();
            c = sql_db.rawQuery("SELECT * FROM " + table_name, null);
            c.moveToFirst();
            do {
                Map<String, String> table_row = new HashMap<String, String>();
                int columnCount = c.getColumnCount();
                int i = 0;
                for (i = 0; i < columnCount; i++) {
                    table_row.put(c.getColumnName(i), c.getString(i));
                }
                table_rows.add(table_row);
            } while (c.moveToNext());
            return table_rows;
        } catch (Exception e) {
            e.printStackTrace();
            return table_rows;
        } finally {
            c.close();
            sql_db.close();
        }
    }

    public List<Map<String, String>> fetchAllRowsDesc(String table_name) {
        SQLiteDatabase sql_db = null;
        Cursor c = null;
        List<Map<String, String>> table_rows = new ArrayList<Map<String, String>>();
        try {
            sql_db = this.connectSQLite();
            c = sql_db.rawQuery("SELECT * FROM " + table_name
                    + " ORDER BY project_id DESC", null);
            c.moveToFirst();
            do {
                Map<String, String> table_row = new HashMap<String, String>();
                int columnCount = c.getColumnCount();
                int i = 0;
                for (i = 0; i < columnCount; i++) {
                    table_row.put(c.getColumnName(i), c.getString(i));
                }
                table_rows.add(table_row);
            } while (c.moveToNext());
            return table_rows;
        } catch (Exception e) {
            e.printStackTrace();
            return table_rows;
        } finally {
            c.close();
            sql_db.close();
        }
    }

    public boolean insertRow(String table_name, Map<String, String> table_row) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            String insertString = "";
            String columnString = "";
            for (Map.Entry me : table_row.entrySet()) {
                insertString = insertString + "'" + me.getValue() + "'" + ",";
                columnString = columnString + "`" + me.getKey() + "`" + ",";
            }
            columnString = columnString.substring(0, columnString.length() - 1);
            insertString = insertString.substring(0, insertString.length() - 1);
            String query1 = "INSERT into " + table_name + "(" + columnString
                    + ") VALUES(" + insertString + ");";
            System.out.println(query1);
             db.execSQL(query1);
            System.out.println("if");

            System.out.println(query1);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public boolean update(String table_name, Map<String, String> table_row,
                          String primary_key) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            String updateString = "";
            for (Map.Entry<String, String> me : table_row.entrySet()) {
                updateString = updateString + "`" + me.getKey() + "`='"
                        + me.getValue() + "',";
            }
            updateString = updateString.substring(0, updateString.length() - 1);
            System.out.println(updateString);
            String query1;
            if (primary_key == null) {
                query1 = "UPDATE " + table_name + " SET " + updateString;
            } else {
                String primary_value = table_row.get(primary_key);
                query1 = "UPDATE " + table_name + " SET " + updateString
                        + " WHERE " + primary_key + "=" + primary_value;
            }
            System.out.println(query1);
            db.execSQL(query1);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public boolean deleteRow(String table_name, String primary_key,
                             String primary_value) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            String query1 = "DELETE FROM " + table_name + " WHERE "
                    + primary_key + "=" + primary_value;
            db.execSQL(query1);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public boolean deleteAllRow(String table_name) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            String query1 = "DELETE FROM " + table_name;
            db.execSQL(query1);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public boolean query(String query) {
        SQLiteDatabase db = null;
        try {
            db = this.connectSQLite();
            db.execSQL(query);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public int data_count(String table_name) {
        try {
            SQLiteDatabase db1 = this.connectSQLite();
            String sql = "SELECT COUNT(*) FROM " + table_name;
            SQLiteStatement statement = db1.compileStatement(sql);
            int count = (int) statement.simpleQueryForLong();
            db1.close();
            if (count > 0) {
                return count;
            } else {
                return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean data_exists(String table_name) {

        try {
            SQLiteDatabase db1 = this.connectSQLite();
            String sql = "SELECT COUNT(*) FROM " + table_name;
            SQLiteStatement statement = db1.compileStatement(sql);
            long count = statement.simpleQueryForLong();
            db1.close();
            return count > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public long rowCount(String table_name) {
        SQLiteDatabase db1 = null;
        SQLiteStatement statement = null;
        try {
            db1 = this.connectSQLite();
            String sql = "SELECT COUNT(*) FROM " + table_name;
            statement = db1.compileStatement(sql);
            long count = statement.simpleQueryForLong();
            return count;
        } catch (Exception e) {
            return 0;
        } finally {
            statement.close();
            db1.close();
        }
    }

}
