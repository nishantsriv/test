package com.buckwalk;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Home.Home;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.Shoplog.Adapter_mystry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ErrandRequestDetails extends AppCompatActivity {
    private ImageView drawer_icon;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private LinearLayout no_request, requests_data;
    private TextView valid_upto_txt, name_txt, service_type_txt, pick_location_txt, drop_location_txt, details_txt, email_txt, mob_no_txt,txtstatus;
    private String id, customer_name, service_type, pick_location, drop_location, proposed_amount, errand_comment, customer_mob, time, saved_time, errands_id, errands_savedby, errands_status;
    private Button amount_btn, accept_btn;
    private HostFile hostFile = new HostFile();
    private RequestQueue requestQueue1, requestQueue2;
    private StringRequest strrequest, strrequest2;
    private String responsestr, responsestr2, user_id;
    private Spinner toolbar_spinner;
    String[] city = {"Gurugram", "Jaipur", "Delhi"};
    ArrayList<Data_Object> errand_request_detail_list = new ArrayList<Data_Object>();
    String errand_id_intent, savedby,Value;

    LoginData loginData = new LoginData();
    LoginDataMapper loginDataMapper = new LoginDataMapper();
    Database db = new Database();
    UserTable usertable = new UserTable();

    ProgressDialog progressDialog;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_errand_request_details);
        findid();
        loginData = loginDataMapper.getInfo("1");
        user_id = loginData.user_id;
        System.out.println("userid"+user_id);
        Intent i = getIntent();
       Value= i.getStringExtra("key");
        System.out.println("Value"+Value);
        if(Value==null)
        {
            errand_id_intent = i.getStringExtra("eid");
            savedby = i.getStringExtra("savedby");

        }
       else{
            errand_id_intent=i.getStringExtra("id");

        }

        progressDialog = ProgressDialog.show(ErrandRequestDetails.this, "", "Please Wait..");
        drawerLayout = (DrawerLayout) findViewById(R.id.errand_request_details_drawer);
        drawer_icon = (ImageView) findViewById(R.id.toolbar_drawer_icon);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_spinner = (Spinner) toolbar.findViewById(R.id.toolbar_spinner);

        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);

        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);

        String Url = hostFile.requesterrand_details(Integer.parseInt(errand_id_intent));
        Log.d("Url", Url);
        requestQueue1 = Volley.newRequestQueue(ErrandRequestDetails.this);
        strrequest = new StringRequest(Request.Method.GET, Url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                responsestr = response;
                Log.d("response", responsestr);
                Log.d("idpassed", errand_id_intent);
                new Asynvolly_ErrandRD().execute();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        });
        requestQueue1.add(strrequest);


        accept_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!user_id.equals(savedby)) {
                    progressDialog = ProgressDialog.show(ErrandRequestDetails.this, "", "Please Wait...");
                    accept_request();
                }else Toast.makeText(ErrandRequestDetails.this, "You can't accept your own request", Toast.LENGTH_SHORT).show();
            }
        });

    }

    class Asynvolly_ErrandAceeptRequest extends AsyncTask<Void, Void, Void> {
        int status2;

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responsestr2);
                JSONObject meta_object = jsonObject.getJSONObject("meta");
                status2 = meta_object.getInt("status");
                System.out.println("status" + status2);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            Toast.makeText(ErrandRequestDetails.this, "Request Accepted", Toast.LENGTH_SHORT).show();
            Home.queue.add(Home.stringRequest);
            finish();
        }
    }


    class Asynvolly_ErrandRD extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responsestr);
                JSONObject meta_object = jsonObject.getJSONObject("meta");
                status = meta_object.getInt("status");
                System.out.println("status" + status);
                JSONObject data_object = jsonObject.getJSONObject("data");
                id = data_object.getString("id");
                System.out.println("id" + id);
                errands_id = data_object.getString("errands_id");
                customer_name = data_object.getString("customer_name");
                service_type = data_object.getString("service_type");
                pick_location = data_object.getString("pick_location");
                drop_location = data_object.getString("drop_location");
                errands_savedby = data_object.getString("errands_savedby");
                proposed_amount = data_object.getString("proposed_amount");
                errand_comment = data_object.getString("errand_comment");
                customer_mob = data_object.getString("customer_mob");
                errands_status = data_object.getString("errands_status");
                saved_time = data_object.getString("saved_time");
                time = data_object.getString("valid");
                errand_request_detail_list.add(new Data_Object(id, customer_name, service_type, pick_location,
                        drop_location, proposed_amount, errand_comment, customer_mob, time, saved_time, errands_id, errands_savedby, errands_status));

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (status == 200) {
                progressDialog.dismiss();
                valid_upto_txt.setText(time);
                name_txt.setText(customer_name);
                service_type_txt.setText(service_type);
                pick_location_txt.setText(pick_location);
                drop_location_txt.setText(drop_location);
                details_txt.setText(errand_comment);
                mob_no_txt.setText(customer_mob);
                amount_btn.setText("Amount: ₹" + proposed_amount);
            } else {
                progressDialog.dismiss();
                no_request.setVisibility(View.VISIBLE);
                requests_data.setVisibility(View.GONE);

            }


        }
    }


    public void accept_request() {
        String url = hostFile.accept_errand_request();
        Log.d("accepturl", url);
        requestQueue2 = Volley.newRequestQueue(ErrandRequestDetails.this);
        strrequest2 = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                responsestr2 = response;
                new Asynvolly_ErrandAceeptRequest().execute();
                Log.d("response2", responsestr2);
                Log.d("errands_id", errands_id);
                Log.d("user_id", user_id);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                if (error instanceof TimeoutError) {
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<String, String>();
                user_id = loginData.user_id;
                params.put("errands_id", errand_id_intent);
                params.put("user_id", user_id);
                System.out.println("userid" + user_id);

                return params;
            }
        };
        requestQueue2.add(strrequest2);
    }

    public void findid() {
        valid_upto_txt = (TextView) findViewById(R.id.valid_upto_time);
        no_request = (LinearLayout) findViewById(R.id.no_requests);
        requests_data = (LinearLayout) findViewById(R.id.data_requests);
        name_txt = (TextView) findViewById(R.id.errand_requester_name);
        service_type_txt = (TextView) findViewById(R.id.errand_requester_service);
        pick_location_txt = (TextView) findViewById(R.id.errand_requester_pick_location);
        drop_location_txt = (TextView) findViewById(R.id.errand_requester_drop_location);
        details_txt = (TextView) findViewById(R.id.errand_requester_details);
        mob_no_txt = (TextView) findViewById(R.id.errand_requester_mobileno);
        email_txt = (TextView) findViewById(R.id.errand_requester_emailid);
        amount_btn = (Button) findViewById(R.id.errand_mentioned_amount_btn);
        accept_btn = (Button) findViewById(R.id.accept_errand_request_btn_);

    }
}
