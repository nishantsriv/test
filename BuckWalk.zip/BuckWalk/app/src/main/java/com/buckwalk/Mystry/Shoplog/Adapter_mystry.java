package com.buckwalk.Mystry.Shoplog;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.JobBoard.JobBoard_Fragment;
import com.buckwalk.Mystry.Mystry_services;
import com.buckwalk.Mystry.Profile.Profile_Fragment;
import com.buckwalk.Mystry.ViewPagerAdapter;
import com.buckwalk.R;
import com.buckwalk.Register.Register;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Nishant on 06-04-2017.
 */

public class Adapter_mystry extends RecyclerView.Adapter<Adapter_mystry.Holder> {
    private LayoutInflater inflater;
    private Context context;
    private ArrayList<Data_shoplog> arrayList;
    private RequestQueue requestQueue;
    private String responseFromVolly, shopid_idcurrent, userid;
    private LoginData loginData;
    private LoginDataMapper loginDataMapper;
    private HostFile hostFile;

    public Adapter_mystry(Context context, ArrayList<Data_shoplog> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        loginData = new LoginData();
        loginDataMapper = new LoginDataMapper();
        loginData = loginDataMapper.getInfo("1");
        userid = loginData.user_id;
        if (arrayList.size() == 0) {
            Shoplog.emptytextview.setVisibility(View.VISIBLE);
        }
        hostFile = new HostFile();
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.model_mystry, parent, false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final Holder holder, final int position) {
        final String shop_id = arrayList.get(position).getShop_id();
        holder.company_name.setText(arrayList.get(position).getShop_rtg());
        holder.location.setText(arrayList.get(position).getAddress());
        holder.date_from.setText(arrayList.get(position).getSurvey_submit_date());
        holder.date_to.setText(arrayList.get(position).getDont_shop_before_date());
        holder.amount.setText(arrayList.get(position).getShop_fees());
        holder.shopmodel_button.setId(Integer.parseInt(arrayList.get(position).getShop_id()));
        holder.shopmodel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shopid_idcurrent = arrayList.get(position).getShop_id();
//                context.sendBroadcast(new Intent("PDshow"));
                RequestQueue queue = Volley.newRequestQueue(context);
                /*final String url = "http://gaganvats.com/Api/mystry_edit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui";*/
                final String url = hostFile.shoplog_button();
                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                responseFromVolly = response;
                                System.out.println("XXX response = " + response);
                                new Async_sendshopid().execute();
                                Log.d("TEST", url + "\n" + response);
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        context.sendBroadcast(new Intent("PDdismiss"));
                        if (error instanceof TimeoutError) {
                            error.printStackTrace();
                        } else if (error instanceof NoConnectionError) {
                            error.printStackTrace();
                        } else if (error instanceof AuthFailureError) {
                            error.printStackTrace();
                        } else if (error instanceof ServerError) {
                            error.printStackTrace();
                        } else if (error instanceof NetworkError) {
                            error.printStackTrace();
                        } else if (error instanceof ParseError) {
                            error.printStackTrace();
                        }
                    }
                }) {
                    @Override
                    public Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();
                        params.put("user_id", userid);
                        params.put("shop_id", shop_id);
                        Log.d("TEST", "" + params);
                        return params;
                    }

                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        HashMap<String, String> map = new HashMap<String, String>();
                        map.put("Content-Type", "application/x-www-form-urlencoded");
                        return map;

                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json; charset=utf-8";
                    }
                };
                queue.add(stringRequest);
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView company_name, location, date_from, date_to, amount;
        Button shopmodel_button;

        public Holder(View itemView) {
            super(itemView);
            company_name = (TextView) itemView.findViewById(R.id.mystry_companyname);
            location = (TextView) itemView.findViewById(R.id.mystry_location);
            date_from = (TextView) itemView.findViewById(R.id.mystry_datefrom);
            date_to = (TextView) itemView.findViewById(R.id.mystry_dateto);
            amount = (TextView) itemView.findViewById(R.id.mystry_amount);
            shopmodel_button = (Button) itemView.findViewById(R.id.shoplog_modelbutton);
        }
    }

    public class Async_sendshopid extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responseFromVolly);
                JSONObject metaonject = jsonObject.getJSONObject("meta");
                status = metaonject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            context.sendBroadcast(new Intent("PDdismiss"));
            if (status == 200) {
                Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
                for (int i = 0; i < arrayList.size(); i++) {
                    if (arrayList.get(i).getShop_id().equals(shopid_idcurrent)) {
                        arrayList.remove(i);
                        JobBoard_Fragment.requestQueue.add(JobBoard_Fragment.stringRequest);
                    }
                }
                dialog();

            } else {
                Toast.makeText(context, "Error: " + status, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void dialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("It will take 24 hours to process!");
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Shoplog.recyclerView.setAdapter(new Adapter_mystry(context, arrayList));
                dialog.dismiss();
            }
        });
        builder.show();
    }
}
