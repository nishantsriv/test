package com.buckwalk.Mystry.Shoplog;

/**
 * Created by nishant on 16-05-2017.
 */

public class Data_shoplog {
    String shop_id, shop_due_date, survey_submit_date, dont_shop_before_date, address, shop_fees, shop_rtg, audit_status;

    public Data_shoplog(String shop_id, String shop_due_date, String survey_submit_date, String dont_shop_before_date, String address, String shop_fees, String shop_rtg, String audit_status) {
        this.shop_id = shop_id;
        this.shop_due_date = shop_due_date;
        this.survey_submit_date = survey_submit_date;
        this.dont_shop_before_date = dont_shop_before_date;
        this.address = address;
        this.shop_fees = shop_fees;
        this.shop_rtg = shop_rtg;
        this.audit_status = audit_status;
    }

    public String getShop_id() {
        return shop_id;
    }

    public String getShop_due_date() {
        return shop_due_date;
    }

    public String getSurvey_submit_date() {
        return survey_submit_date;
    }

    public String getDont_shop_before_date() {
        return dont_shop_before_date;
    }

    public String getAddress() {
        return address;
    }

    public String getShop_fees() {
        return shop_fees;
    }

    public String getShop_rtg() {
        return shop_rtg;
    }

    public String getAudit_status() {
        return audit_status;
    }
}
