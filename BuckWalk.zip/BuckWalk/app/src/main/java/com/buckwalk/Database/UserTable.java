package com.buckwalk.Database;

/**
 * Created by Saurabh on 08-05-2017.
 */

public class UserTable {

    public UserTable(){
        login();
    }

    public boolean login() {
        Database db = new Database();
        String columns[] = new String[11];
        columns[0] = "id VARCHAR";
        columns[1] = "user_id VARCHAR";
        columns[2] = "user_name VARCHAR";
        columns[3] = "user_email VARCHAR";
        columns[4] = "user_phone VARCHAR";
        columns[5] = "user_location VARCHAR";
        columns[6] = "user_image VARCHAR";
        columns[7] = "user_city VARCHAR";
        columns[8] = "user_state VARCHAR";
        columns[9] = "user_country VARCHAR";
        columns[10] = "user_pincode VARCHAR";

        db.createTableIfNotExists("UserLogin", columns);
        return true;
    }

}