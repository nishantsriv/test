package com.buckwalk;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Drawer.DrawerFragment;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.JobBoard.JobBoard_Fragment;
import com.buckwalk.Mystry.Mystry_services;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ProofOfVisit extends AppCompatActivity {
    private int hour, min;
    private DrawerFragment drawerFragment;
    private DrawerLayout drawerLayout;
    private ImageView drawer_icon;
    private static final int FILE_SELECT_CODE = 0;
    private Button filepickerbtn, submitbtn;
    private Calendar calendar;
    private DatePickerDialog.OnDateSetListener date;
    private LinearLayout calendarpickbtn, intimepickerbtn, outtimepickerbtn;
    private TextView datetext, intimetext, outtimetext, filetext;
    private TimePickerDialog.OnTimeSetListener intime, outtime;
    private Toolbar toolbar;
    private EditText editText_companyname, edittxt_mobilenumber;
    private String imagebase64, responsefromVolley, shopid, userid;
    private LoginData loginData;
    private LoginDataMapper loginDataMapper;
    private ProgressDialog progressDialog;
    private Spinner toolbar_spinner;
    private TimePickerDialog in_timePickerDialog;
    String[] city = {"Gurugram", "Jaipur", "Delhi"};

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proof_of_visit);


        loginData = new LoginData();
        loginDataMapper = new LoginDataMapper();
        loginData = loginDataMapper.getInfo("1");
        userid = loginData.user_id;
        submitbtn = (Button) findViewById(R.id.proofvisit_submitbtn);
        edittxt_mobilenumber = (EditText) findViewById(R.id.proofvisit_mobilenumber);
        final String companyname = getIntent().getStringExtra("shopname");
        shopid = getIntent().getStringExtra("shop_id");
        editText_companyname = (EditText) findViewById(R.id.proofvisit_edittxtshopname);
        editText_companyname.setText(companyname);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawer_icon = (ImageView) toolbar.findViewById(R.id.toolbar_drawer_icon);
        filetext = (TextView) findViewById(R.id.pof_filetext);
        drawerLayout = (DrawerLayout) findViewById(R.id.pof_drawer_layout);
        filepickerbtn = (Button) findViewById(R.id.pof_choosefile);
        datetext = (TextView) findViewById(R.id.pof_date);
        intimepickerbtn = (LinearLayout) findViewById(R.id.intimepicker);
        outtimepickerbtn = (LinearLayout) findViewById(R.id.outtimepicker);
        intimetext = (TextView) findViewById(R.id.pof_intime);
        outtimetext = (TextView) findViewById(R.id.pof_outtime);
        calendarpickbtn = (LinearLayout) findViewById(R.id.pof_calendarpick);
        calendar = Calendar.getInstance();
        drawerFragment = new DrawerFragment();

        /*Sppinner*/
        toolbar_spinner = (Spinner) toolbar.findViewById(R.id.toolbar_spinner);
        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);
        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);


        if (null == savedInstanceState) {

            FragmentManager manager = getSupportFragmentManager();
            FragmentTransaction transaction = manager.beginTransaction();
            transaction.replace(R.id.drawer_fragment_left, drawerFragment, "drawer_frag");
            transaction.commit();
        }

        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updatedatelabel();
            }
        };
        calendarpickbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(ProofOfVisit.this, date, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        intime = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                hour = hourOfDay;
                min = minute;
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                updateintimelabel();
            }
        };

        outtime = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);
                updateouttimelabel();
            }
        };


        intimepickerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(ProofOfVisit.this, intime, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false).show();

            }
        });
        outtimepickerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if ((hour != 0) && (min != 0))
                    new TimePickerDialog(ProofOfVisit.this, outtime, hour, min, false).show();
                else
                    Toast.makeText(ProofOfVisit.this, "Please input intime first", Toast.LENGTH_SHORT).show();
            }
        });
        filepickerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                startActivityForResult(intent, FILE_SELECT_CODE);
            }
        });

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((!companyname.equals("")) && (!datetext.getText().equals("")) && (!intimetext.getText().toString().equals("")) && (!outtimetext.getText().toString().equals("")) && (!edittxt_mobilenumber.getText().toString().equals("")) && (imagebase64 != null)) {
                    if (edittxt_mobilenumber.getText().length() < 10) {
                        Toast.makeText(ProofOfVisit.this, "Incomplete mobile number", Toast.LENGTH_SHORT).show();
                    } else {
                        progressDialog = ProgressDialog.show(ProofOfVisit.this, "", "Submitting...");
                        RequestQueue queue = Volley.newRequestQueue(ProofOfVisit.this);
                        String url = new HostFile().proofvisit_submit();
                        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                responsefromVolley = response;
                                new Asyncproofvisit().execute();
                                showdialog();
                                Log.d("TEST_PROOF", responsefromVolley);
                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                progressDialog.dismiss();
                                if (error instanceof TimeoutError) {
                                    error.printStackTrace();
                                } else if (error instanceof NoConnectionError) {
                                    error.printStackTrace();
                                } else if (error instanceof AuthFailureError) {
                                    error.printStackTrace();
                                } else if (error instanceof ServerError) {
                                    error.printStackTrace();
                                } else if (error instanceof NetworkError) {
                                    error.printStackTrace();
                                } else if (error instanceof ParseError) {
                                    error.printStackTrace();
                                }
                            }
                        }) {
                            @Override
                            public Map<String, String> getParams() throws AuthFailureError {
                                HashMap<String, String> params = new HashMap<String, String>();
                                params.put("shop_id", shopid);
                                params.put("audit_date", datetext.getText().toString());
                                params.put("audit_intime", intimetext.getText().toString());
                                params.put("audit_outtime", outtimetext.getText().toString());
                                params.put("mobileno", edittxt_mobilenumber.getText().toString());
                                params.put("proof", imagebase64);
                                params.put("user_id", userid);
                                Log.d("TEST", "" + params);
                                return params;
                            }

                            @Override
                            public Map<String, String> getHeaders() throws AuthFailureError {
                                HashMap<String, String> map = new HashMap<String, String>();
                                map.put("Content-Type", "application/x-www-form-urlencoded");
                                return map;

                            }

                            @Override
                            public String getBodyContentType() {
                                return "application/json; charset=utf-8";
                            }
                        };
                        queue.add(stringRequest);
                    }
                } else {
                    Toast.makeText(ProofOfVisit.this, "Complete all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
            Uri uri = data.getData();
            filetext.setText(uri.getPath());
            try {
                /*compressing bitmap by userpicture.java class*/
                imagebase64 = encodeImage(new UserPicture(uri, getContentResolver()).getBitmap());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String encodeImage(Bitmap bm) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] b = baos.toByteArray();
        String encImage = Base64.encodeToString(b, Base64.DEFAULT);

        return encImage;
    }

    private void updateouttimelabel() {
        String myformat = "HH:mm";
        SimpleDateFormat sdf = new SimpleDateFormat(myformat, Locale.US);
        outtimetext.setText(sdf.format(calendar.getTime()));
    }

    private void updateintimelabel() {
        String myformat = "HH:mm";
        SimpleDateFormat sdf = new SimpleDateFormat(myformat, Locale.US);
        intimetext.setText(sdf.format(calendar.getTime()));
    }

    private void updatedatelabel() {
        String myformat = "dd/MM/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myformat, Locale.US);
        datetext.setText(sdf.format(calendar.getTime()));
    }


    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    public class Asyncproofvisit extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responsefromVolley);
                JSONObject metaobject = jsonObject.getJSONObject("meta");
                status = metaobject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            if (status == 200) {
                JobBoard_Fragment.requestQueue.add(JobBoard_Fragment.stringRequest);
                Mystry_services.tabLayout.getTabAt(1).select();
            } else {
                Toast.makeText(ProofOfVisit.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void showdialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("It will take 24 hours to accept your request");
        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                Toast.makeText(ProofOfVisit.this, "Submitted", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        builder.show();
    }
}