package com.buckwalk.Drawer;


import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amulyakhare.textdrawable.TextDrawable;
import com.buckwalk.AllRequests;
import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Home.Home;
import com.buckwalk.Login.Login;
import com.buckwalk.R;
import com.buckwalk.RippleView;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * Created by Saurabh on 17-04-2017.
 */

public class DrawerFragment extends Fragment {

    TextView name_textview;
    CircleImageView name_imageview;
    String name_string;
    String image_url;
    LinearLayout logout, drawer_home, request_service, drawer_share;

    Database db = new Database();
    UserTable table = new UserTable();
    LoginData loginData = new LoginData();
    LoginDataMapper loginDataMapper = new LoginDataMapper();


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.drawer_view, container, false);
        drawer_share = (LinearLayout) view.findViewById(R.id.drawer_share);
        drawer_home = (LinearLayout) view.findViewById(R.id.drawer_home);
        name_textview = (TextView) view.findViewById(R.id.drawer_name_textview);
        name_imageview = (CircleImageView) view.findViewById(R.id.drawer_name_imageview);
        request_service = (LinearLayout) view.findViewById(R.id.request_service);

        logout = (LinearLayout) view.findViewById(R.id.drawer_logout);

        if (db.data_exists("UserLogin")) {
            loginData = loginDataMapper.getInfo("1");
            name_string = loginData.name;
            image_url = loginData.image;
            String name_capital = toTitleCase(name_string);
            name_textview.setText(name_capital);

            if (image_url.isEmpty() || image_url == null) {
                if (!name_string.isEmpty() || name_string != null) {
                    char first = toTitleCase(toTitleCase(name_string)).charAt(0);
                    TextDrawable drawable1 = TextDrawable.builder()
                            .beginConfig()
                            .textColor(getResources().getColor(R.color.home_screen_main_color))
                            .bold()
                            .toUpperCase()
                            .endConfig()
                            .buildRound(String.valueOf(first), getResources().getColor(R.color.white));

                    name_imageview.setImageDrawable(drawable1);
                }

            } else {
                DisplayImageOptions displayImageOptions = new DisplayImageOptions.Builder()
                        .cacheInMemory(true)
                        .cacheOnDisk(true)
//                        .showImageForEmptyUri(R.drawable.ic_empty)
//                        .showImageOnFail(R.drawable.ic_empty)
//                        .showImageOnLoading(R.drawable.ic_empty)
                        .build();

                ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getActivity())
                        .defaultDisplayImageOptions(displayImageOptions)
                        .build();

                ImageLoader.getInstance().init(config);
                ImageLoader.getInstance().displayImage(image_url, name_imageview);
            }

        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.deleteAllRow("UserLogin");
                Intent i = new Intent(getActivity(), Login.class);
                startActivity(i);
            }
        });


        request_service.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), AllRequests.class);
//                startActivity(i);
            }
        });
        drawer_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), Home.class);
                startActivity(i);
            }
        });
        drawer_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Uri imageUri = null;
                    try {
                        imageUri = Uri.parse(MediaStore.Images.Media.insertImage(getActivity().getContentResolver(),
                                BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher), null, null));
                    } catch (NullPointerException e) {
                        e.printStackTrace();
                    }

                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("*/*");
                    shareIntent.putExtra(Intent.EXTRA_TEXT, "Hello!");

                    shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);

                    startActivity(shareIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getActivity(), "no app fount", Toast.LENGTH_LONG).show();
                }
            }
        });
        return view;
    }

    public static String toTitleCase(String givenString) {
        StringBuffer sb = new StringBuffer();
        if (givenString == givenString.toLowerCase()) {
            String[] arr = givenString.split(" ");
            for (int i = 0; i < arr.length; i++) {
                sb.append(Character.toUpperCase(arr[i].charAt(0)))
                        .append(arr[i].substring(1)).append(" ");
            }
        } else
            return givenString;
        return sb.toString().trim();
    }
}
