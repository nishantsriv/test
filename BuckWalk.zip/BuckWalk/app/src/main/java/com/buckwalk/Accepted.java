package com.buckwalk;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Host.HostFile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Accepted extends Fragment {
    private RecyclerView recyclerView;
    private StringRequest stringRequest;
    private RequestQueue requestQueue;
    private LinearLayoutManager layoutManager;
    private String responseformvolly,user_id;
    private Spinner errands_spinner;
    private ArrayAdapter<CharSequence> adapter2;
    private ProgressDialog progressDialog;
    private ArrayList<Data_Accepted> pending_arraylist=new ArrayList<Data_Accepted>();
    private ArrayList<Data_Accepted>  accepted_arraylist=new ArrayList<Data_Accepted>();
    private ArrayList<Data_Accepted>  processing_arraylist=new ArrayList<Data_Accepted>();
    private AcceptedFragAdapter acceptedFragAdapter;
    HostFile hostFile=new HostFile();
    LoginData loginData=new LoginData();
    LoginDataMapper loginDataMapper=new LoginDataMapper();
   public Accepted()
   {

   }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_accepted,container,false);
        recyclerView=(RecyclerView)view.findViewById(R.id.acepted_recyclerview);
        progressDialog=progressDialog.show(getActivity(),"","Please Wait..");
        loginData=loginDataMapper.getInfo("1");
        user_id=loginData.user_id;

         /*spinner*/
        errands_spinner=(Spinner)view.findViewById(R.id.errands_accept_spinner);
        adapter2 = ArrayAdapter.createFromResource(getActivity(),R.array.job_status,android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        errands_spinner.setAdapter(adapter2);
        /*spinner*/


        String url=hostFile.useraccepted_errand(Integer.parseInt(user_id));
        System.out.println("url Accepted"+url);
        requestQueue= Volley.newRequestQueue(getActivity());
        stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                responseformvolly=response;
                System.out.println("Response Accepted"+responseformvolly);
                new Asynvolly_Acceptedrequest().execute();
            }
        },
                new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                if (error instanceof TimeoutError) {
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }

            }
        });
        requestQueue.add(stringRequest);
        layoutManager=new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        errands_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               if(parent.getSelectedItem().equals("Processing"))
               {
                   recyclerView.setAdapter(new AcceptedFragAdapter(getActivity(),processing_arraylist));
               }
               else if(parent.getSelectedItem().equals("Pending"))
               {
                   recyclerView.setAdapter(new AcceptedFragAdapter(getActivity(),pending_arraylist));
               }
               else if(parent.getSelectedItem().equals("Completed"))
               {
                   recyclerView.setAdapter(new AcceptedFragAdapter(getActivity(),accepted_arraylist));
               }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }

    class Asynvolly_Acceptedrequest extends AsyncTask<Void,Void,Void>
    {int status;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try{
                JSONObject jsonObject=new JSONObject(responseformvolly);
                JSONObject meta_data=jsonObject.getJSONObject("meta");
                status=meta_data.getInt("status");
                System.out.println("status"+status);
                JSONArray jsonArray=jsonObject.getJSONArray("data");
                for(int i=0;i<jsonArray.length();i++)
                {
                    JSONObject jsonarrayobject=jsonArray.getJSONObject(i);
                    String id=jsonarrayobject.getString("id");
                    String errands_id=jsonarrayobject.getString("errands_id");
                    String customer_name=jsonarrayobject.getString("customer_name");
                    String service_type=jsonarrayobject.getString("service_type");
                    String pick_location=jsonarrayobject.getString("pick_location");
                    String drop_location=jsonarrayobject.getString("drop_location");
                    String errands_savedby=jsonarrayobject.getString("errands_savedby");
                    String proposed_amount=jsonarrayobject.getString("proposed_amount");
                    String customer_mob=jsonarrayobject.getString("customer_mob");
                    String errands_status=jsonarrayobject.getString("errands_status");
                    String saved_time=jsonarrayobject.getString("saved_time");
                    String valid=jsonarrayobject.getString("valid");
                    String name=jsonarrayobject.getString("name");
                    String mobile=jsonarrayobject.getString("mobile");
                    switch (errands_status)
                    {
                        case "2":
                            pending_arraylist.add(new Data_Accepted(id,errands_id,customer_name,service_type,
                            pick_location,drop_location,errands_savedby,proposed_amount,
                            customer_mob,errands_status,saved_time,valid,name,mobile));
                            break;
                        case "3":
                        processing_arraylist.add(new Data_Accepted(id,errands_id,customer_name,service_type,
                            pick_location,drop_location,errands_savedby,proposed_amount,
                            customer_mob,errands_status,saved_time,valid,name,mobile));
                            break;
                        case "4":
                            accepted_arraylist.add(new Data_Accepted(id,errands_id,customer_name,service_type,
                            pick_location,drop_location,errands_savedby,proposed_amount,
                            customer_mob,errands_status,saved_time,valid,name,mobile));
                            break;
                    }

                }
            }
            catch (JSONException e)
            {
               e.printStackTrace();
            }
            return  null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (status == 200) {
                if (errands_spinner.getSelectedItem().equals("Pending")) {
                    recyclerView.setAdapter(new AcceptedFragAdapter(getActivity(),pending_arraylist));
                } else if (errands_spinner.getSelectedItem().equals("Processing")) {
                    recyclerView.setAdapter(new AcceptedFragAdapter( getActivity(),processing_arraylist));
                } else if (errands_spinner.getSelectedItem().equals("Completed")) {
                    recyclerView.setAdapter(new AcceptedFragAdapter( getActivity(),accepted_arraylist));
                }

            } else {
                Toast.makeText(getActivity(), "Something went wrong", Toast.LENGTH_SHORT).show();
            }
            progressDialog.dismiss();
        }
    }
}
