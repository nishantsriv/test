package com.buckwalk.Home;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.buckwalk.ErrandListDataObject;
import com.buckwalk.ErrandRequestDetails;
import com.buckwalk.R;

import java.net.URISyntaxException;
import java.util.ArrayList;

/**
 * Created by Saurabh on 06-04-2017.
 */

public class PostRecyclerAdapter extends RecyclerView.Adapter<PostRecyclerAdapter.PostRecyclerViewHolder> {

    Context context;
    ArrayList<ErrandListDataObject> errandList = new ArrayList<ErrandListDataObject>();
    public PostRecyclerAdapter(Context context,ArrayList<ErrandListDataObject> errandList) {
        this.context = context;
        this.errandList = errandList;
    }

    @Override
    public PostRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.home_posted_recycler_model,parent,false);
        return new PostRecyclerViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final PostRecyclerViewHolder holder, final int position) {
        try {
            holder.main_layout.setId(Integer.parseInt(errandList.get(position).getId()));
            holder.name.setText(errandList.get(position).getCustomer_name());
            holder.service_name.setText(errandList.get(position).getService_type());
            holder.pickup_locatio.setText(errandList.get(position).getPickup_loc());
            holder.drop_location.setText(errandList.get(position).getDrop_loc());
            holder.proposed_amount.setText(" ₹ "+errandList.get(position).getProposed_amount());

            holder.main_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context, ErrandRequestDetails.class);
                    i.putExtra("eid",errandList.get(position).getId());
                    i.putExtra("savedby",errandList.get(position).getErrand_savedby());

                    context.startActivity(i);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return errandList.size();
    }

    public class PostRecyclerViewHolder extends RecyclerView.ViewHolder {

        TextView name;
        TextView service_name;
        TextView pickup_locatio;
        TextView drop_location;
        TextView proposed_amount;
        FrameLayout main_layout;

        public PostRecyclerViewHolder(View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.home_recycler_name);
            service_name = (TextView) itemView.findViewById(R.id.home_recycler_service_name);
            pickup_locatio = (TextView) itemView.findViewById(R.id.home_recycler_pickupLocation);
            drop_location = (TextView) itemView.findViewById(R.id.home_recycler_dropLocation);
            proposed_amount = (TextView) itemView.findViewById(R.id.home_recycler_amount);
            main_layout = (FrameLayout) itemView.findViewById(R.id.home_recycler_main_layout);
        }
    }

}