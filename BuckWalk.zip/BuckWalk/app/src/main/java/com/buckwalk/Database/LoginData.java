package com.buckwalk.Database;

import java.util.Map;

/**
 * Created by Saurabh on 08-05-2017.
 */

public class LoginData {

    public String id;
    public String user_id;
    public String name;
    public String email;
    public String phone;
    public String location;
    public String image;
    public String city;
    public String state;
    public String country;
    public String pincode;


    public LoginData() {

    }

    public LoginData(Map<String,String> select_info) {

        id = select_info.get("id");
        user_id = select_info.get("user_id");
        name = select_info.get("user_name");
        email = select_info.get("user_email");
        phone = select_info.get("user_phone");
        location = select_info.get("user_location");
        image = select_info.get("user_image");
        city = select_info.get("user_city");
        state = select_info.get("user_state");
        country = select_info.get("user_country");
        pincode = select_info.get("user_pincode");

    }
}
