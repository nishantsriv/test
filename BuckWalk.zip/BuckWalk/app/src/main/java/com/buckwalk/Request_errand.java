package com.buckwalk;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Home.Home;
import com.buckwalk.Host.HostFile;
import com.buckwalk.Mystry.Profile.LocationService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Request_errand extends AppCompatActivity implements View.OnClickListener {
    private DrawerLayout drawerLayout;
    private ImageView drawer_icon, picklocationbtn, droplocationbtn;
    private Toolbar toolbar;
    private Spinner toolbar_spinner, errand_spinner;
    private String[] city = {"Gurugram", "Jaipur", "Delhi"};
    private String[] vallid_upto_show = {"Immediate", "1 hour", "2 hours", "3 hours", "4 hours", "5 hours", "6 hours",
            "7 hours", "8 hours", "9 hours", "10 hours", "11 hours", "12 hours"};
    private String[] valid_upto = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
    private BroadcastReceiver receiver;
    private Button request_btn;
    private EditText nameedittxt, servicename_edittxt, pickedittxt, mobile_edittxt, dropedittxt, proposededittxt, comment1_edittxt, comment2_edittxt, comment3_edittxt, comment4_edittxt, comment5_edittxt, comment6_edittxt, comment7_edittxt;
    private String comments, responsefromVolley, userid;
    private ProgressDialog progressDialog;
    private LoginData loginData;
    private LoginDataMapper loginDataMapper;
    private String errand_valid_upto;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_errand);
        mobile_edittxt = (EditText) findViewById(R.id.errand_mobileedittxt);
        loginData = new LoginData();
        loginDataMapper = new LoginDataMapper();
        loginData = loginDataMapper.getInfo("1");
        userid = loginData.user_id;
        servicename_edittxt = (EditText) findViewById(R.id.errand_servicename);
        nameedittxt = (EditText) findViewById(R.id.errand_name);
        pickedittxt = (EditText) findViewById(R.id.errand_pickedittxt);
        dropedittxt = (EditText) findViewById(R.id.errand_dropedittxt);
        proposededittxt = (EditText) findViewById(R.id.errand_proposed);
        comment1_edittxt = (EditText) findViewById(R.id.errand_addcomment1);
        comment2_edittxt = (EditText) findViewById(R.id.errand_addcomment2);
        comment3_edittxt = (EditText) findViewById(R.id.errand_addcomment3);
        comment4_edittxt = (EditText) findViewById(R.id.errand_addcomment4);
        comment5_edittxt = (EditText) findViewById(R.id.errand_addcomment5);
        comment6_edittxt = (EditText) findViewById(R.id.errand_addcomment6);
        comment7_edittxt = (EditText) findViewById(R.id.errand_addcomment7);
        request_btn = (Button) findViewById(R.id.errand_requestbtn);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Fetching Location");
        progressDialog.setCancelable(false);
//        picklocationbtn = (ImageView) findViewById(R.id.errand_pickbtn);
//        picklocationbtn.setOnClickListener(this);
//        droplocationbtn = (ImageView) findViewById(R.id.errand_dropbtn);
//        droplocationbtn.setOnClickListener(this);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_spinner = (Spinner) toolbar.findViewById(R.id.toolbar_spinner);
        errand_spinner = (Spinner) findViewById(R.id.errand_spinner);

        ArrayAdapter<String> arrayAdapter_errand = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, vallid_upto_show);
        arrayAdapter_errand.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        errand_spinner.setAdapter(arrayAdapter_errand);
        errand_spinner.setTag(valid_upto);

        errand_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                errand_valid_upto = valid_upto[position];
                System.out.println("XXXX valid = " + errand_valid_upto);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        drawer_icon = (ImageView) toolbar.findViewById(R.id.toolbar_drawer_icon);
        drawerLayout = (DrawerLayout) findViewById(R.id.home_drawer_layout);
        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);
        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                progressDialog.dismiss();
                SharedPreferences preferences = context.getSharedPreferences("locationpref", Context.MODE_PRIVATE);
                String lat = preferences.getString("lat", null);
                Toast.makeText(context, "Recieved" + lat, Toast.LENGTH_SHORT).show();
            }
        };
        registerReceiver(receiver, new IntentFilter("LOCATION"));

        request_btn.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if (v == picklocationbtn) {

        } else if (v == droplocationbtn) {

        } else if (v == request_btn) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(comment1_edittxt.getText()).append(comment2_edittxt.getText()).append(comment3_edittxt.getText()).append(comment4_edittxt.getText()).append(comment5_edittxt.getText()).append(comment6_edittxt.getText()).append(comment7_edittxt.getText());
            comments = stringBuilder.toString();
            if ((!nameedittxt.getText().toString().equals("")) && (!pickedittxt.getText().toString().equals("")) && (!servicename_edittxt.getText().toString().equals("")) && (!dropedittxt.getText().toString().equals("")) && (!proposededittxt.getText().toString().equals("")) && (!comments.equals("")) && (!mobile_edittxt.getText().toString().equals(""))) {
                if (mobile_edittxt.getText().length() < 10) {
                    Toast.makeText(this, "Please enter corrct mobile number", Toast.LENGTH_SHORT).show();
                } else {
                    progressDialog = ProgressDialog.show(this, "", "Submitting");
                    RequestQueue queue = Volley.newRequestQueue(this);
                    String url = new HostFile().requesterrand_submit();
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            responsefromVolley = response;
                            new Asyncerrandrequest().execute();
                            Log.d("TEST", response);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            progressDialog.dismiss();
                            if (error instanceof TimeoutError) {
                                error.printStackTrace();
                            } else if (error instanceof NoConnectionError) {
                                error.printStackTrace();
                            } else if (error instanceof AuthFailureError) {
                                error.printStackTrace();
                            } else if (error instanceof ServerError) {
                                error.printStackTrace();
                            } else if (error instanceof NetworkError) {
                                error.printStackTrace();
                            } else if (error instanceof ParseError) {
                                error.printStackTrace();
                            }

                        }
                    }) {

                        @Override
                        public Map<String, String> getParams() throws AuthFailureError {
                            HashMap<String, String> params = new HashMap<String, String>();
                            params.put("userid", userid);
                            params.put("valid_upto", errand_valid_upto);
                            params.put("customer_name", nameedittxt.getText().toString().replaceAll(" ", "%20").replaceAll(",", "_|_"));
                            params.put("pick_location", pickedittxt.getText().toString());
                            params.put("drop_location", dropedittxt.getText().toString());
                            params.put("proposed_amount", proposededittxt.getText().toString());
                            params.put("Mobileno", mobile_edittxt.getText().toString());
                            params.put("what_to_do", comments);
                            params.put("service_type", servicename_edittxt.getText().toString());
                            Log.d("TEST", "" + params);
                            return params;
                        }

                        @Override
                        public Map<String, String> getHeaders() throws AuthFailureError {
                            HashMap<String, String> map = new HashMap<String, String>();
                            map.put("Content-Type", "application/x-www-form-urlencoded");
                            return map;

                        }

                        @Override
                        public String getBodyContentType() {
                            return "application/json; charset=utf-8";
                        }
                    };
                    queue.add(stringRequest);
                }

            } else {
                Toast.makeText(this, "Complete all fields", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(receiver);
    }

    class Asyncerrandrequest extends AsyncTask<Void, Void, Void> {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try {
                JSONObject jsonObject = new JSONObject(responsefromVolley);
                status = jsonObject.getInt("status");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            if (status == 200) {
                Toast.makeText(Request_errand.this, "Requested Succssfully", Toast.LENGTH_SHORT).show();
                Home.queue.add(Home.stringRequest);
                finish();
            } else {
                Toast.makeText(Request_errand.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
