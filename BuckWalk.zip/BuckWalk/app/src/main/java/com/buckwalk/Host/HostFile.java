package com.buckwalk.Host;

/**
 * Created by Saurabh on 06-05-2017.
 */

public class HostFile {
    String baseUrl2 = "http://gaganvats.com/Api/";
    //    String baseUrl = "http://gaganvats.com/Api/";
    String quesmark = "?";
    String and = "&";
    String equals = "=";
    String usertokenValue = "rfh97ydhnfc89uf89dsf";
    String usernameValue = "test";
    String userkeyValue = "4h3rufch7yzhfu7ynzui";
    String usertoken = "usertoken";
    String username = "username";
    String userkey = "userkey";
    String eid = "eid";
    String userid = "userid";


    //    "http://gaganvats.com/Api/login.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui"
    public String loginUser() {
        String mainUrl = baseUrl2 + "login.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + userkeyValue;
        return mainUrl;
    }

    //    http://gaganvats.com/Api/Register.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String registerUser() {
        String mainUrl = baseUrl2 + "Register.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + userkeyValue;
        return mainUrl;
    }

    //    http://gaganvats.com/Api/update_profile.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String UpdateUser() {
        String mainurl = baseUrl2 + "update_profile.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + userkeyValue;
        return mainurl;
    }

    //    http://gaganvats.com/Api/all_audit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String ShopUrl() {
        String mainurl = baseUrl2 + "all_audit.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + userkeyValue;
        return mainurl;
    }

    //    http://gaganvats.com/Api/mystry_edit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String shoplog_button() {
        String mainurl = baseUrl2 + "mystry_edit.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + "=" +
                userkeyValue;
        return mainurl;
    }

    //    http://localhost/Api/audit_proof.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String proofvisit_submit() {
        String mainurl = baseUrl2 + "/audit_proof.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + "=" + userkeyValue;
        return mainurl;
    }

    //    http://gaganvats.com/Api/Errands.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String requesterrand_submit() {
        String mainurl = baseUrl2 + "Errands.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + "=" + userkeyValue;
        return mainurl;
    }

    //    http://gaganvats.com/Api/errands_list.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String errandreqList() {
        String mainurl = baseUrl2 + "errands_list.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + "=" + userkeyValue;
        return mainurl;
    }

    public String requesterrand_details(int id) {
        String mainurl = baseUrl2 + "errand_detail.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + "=" + userkeyValue;
        String param = String.valueOf(id);
        String url = mainurl + and + eid + equals + id;
        return url;
    }

    //    http://gaganvats.com/Api/user_allaudit.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui&user_id=
    public String job_board() {
        String mainUrl = baseUrl2 + "user_allaudit.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + equals + userkeyValue + and + "user_id" + equals;
        return mainUrl;
    }

    public String accept_errand_request() {
        String mainUrl = baseUrl2 + "errand_accept.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + userkeyValue;
        return mainUrl;
    }

    //http://gaganvats.com/Api/user_errands.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui&userid=1//
    public String user_errands(int id) {
        String mainUrl = baseUrl2 + "user_errands.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey
                + equals + userkeyValue + and + userid;
        String param = String.valueOf(id);
        String url = mainUrl + equals + param;
        return url;
    }

    //http://nexusjobz.com/Api/errand_denied.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui//
    public String errand_denied() {
        String mainUrl = baseUrl2 + "errand_denied.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + equals + userkeyValue;
        return mainUrl;
    }
    //http://gaganvats.com/Api/useraccepted_errand.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui&userid=1//
public String useraccepted_errand(int id)
{
    String mainUrl=baseUrl2 +"useraccepted_errand.php"+quesmark +usertoken+equals+usertokenValue+and+username+equals+usernameValue+and+userkey+equals+usernameValue+and;
    String param =String.valueOf(id);
    String Url=mainUrl+userid+equals+param;
    return Url;
}
//http://gaganvats.com/Api/usersaved_errands.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui&userid=1//
public  String userrequested_errand(int id)
{
    String mainUrl=baseUrl2+"usersaved_errands.php"+ quesmark+usertoken+equals+usertokenValue+and+username+equals+usernameValue+and+userkey+equals+userkeyValue+and;
    String param =String.valueOf(id);
    String Url=mainUrl+userid+equals+param;
    return Url;
}

    //    http://gaganvats.com/Api/fcm.php?usertoken=rfh97ydhnfc89uf89dsf&username=test&userkey=4h3rufch7yzhfu7ynzui
    public String home_fcmid() {
        String main_Url = baseUrl2 + "fcm.php" + quesmark + usertoken + equals + usertokenValue + and + username + equals + usernameValue + and + userkey + equals + userkeyValue;
        return main_Url;
    }
}