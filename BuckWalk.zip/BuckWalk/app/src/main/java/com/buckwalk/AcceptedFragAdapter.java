package com.buckwalk;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Host.HostFile;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by SAMSUNG on 5/20/2017.
 */

public class AcceptedFragAdapter extends RecyclerView.Adapter<AcceptedFragAdapter.Holder>{

    private Context context;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    private ProgressDialog progressDialog;
    private String responsefromvolly,userid,errandsid;
    private ArrayList<Data_Accepted> allrequests;
    private LayoutInflater layoutInflater;
    HostFile hostFile=new HostFile();
    LoginData loginData=new LoginData();
    LoginDataMapper loginDataMapper=new LoginDataMapper();

    public AcceptedFragAdapter(Context context,ArrayList<Data_Accepted> arrayList) {
        this.context = context;
        this.allrequests=arrayList;
        this.layoutInflater=LayoutInflater.from(context);
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v=layoutInflater.inflate(R.layout.model_errand_all_requests,parent,false);
        Holder holder=new Holder(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(final Holder holder, final int position) {
String status2=null;
        if(allrequests.get(position).getErrands_status().equals("4"))
        {
           holder.cancel_btn.setVisibility(View.GONE);
            status2="Completed";
        }
        else if(allrequests.get(position).getErrands_status().equals("3"))
        {
            status2="Processing";
        }
        else if(allrequests.get(position).getErrands_status().equals("2"))
        {
            status2="Pending";
        }
        holder.comp_name.setText(allrequests.get(position).getCustomer_name());
        holder.location.setText(allrequests.get(position).getDrop_location());
        holder.date_to.setText(allrequests.get(position).getValid());
        holder.amount.setText(allrequests.get(position).getProposed_amount());
        final String finalStatus = status2;
        holder.model_requests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context,ErrandRequestDetails.class);
                i.putExtra("status",finalStatus);
                i.putExtra("id",allrequests.get(position).getId());
                i.putExtra("key","Intent");
                context.startActivity(i);
            }
        });
        holder.cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancel_btn();
            }
        });



    }

    @Override
    public int getItemCount() {
        return allrequests.size();
    }

    public class Holder extends RecyclerView.ViewHolder{
        TextView comp_name,location,date_from,date_to,amount,status;
        Button cancel_btn;
        LinearLayout model_requests;
        public Holder(View itemView) {
            super(itemView);
            comp_name=(TextView)itemView.findViewById(R.id.allrequests_companyname);
            location=(TextView)itemView.findViewById(R.id.allrequests_location);
            date_from=(TextView)itemView.findViewById(R.id.allrequests_datefrom);
            date_to=(TextView)itemView.findViewById(R.id.allrequests_dateto);
            amount=(TextView)itemView.findViewById(R.id.allrequests_amount);
            cancel_btn=(Button)itemView.findViewById(R.id.cancel_btn);
            model_requests=(LinearLayout)itemView.findViewById(R.id.requestes);

        }
    }
    public  void cancel_btn()
    {progressDialog =ProgressDialog.show(context,"","Loading..");
        String Url=hostFile.errand_denied();
        System.out.println("Url"+Url);
        requestQueue= Volley.newRequestQueue(context);
        stringRequest=new StringRequest(Request.Method.POST, Url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
              responsefromvolly=response;
                System.out.println("response"+responsefromvolly);
                new Asynvolly_cancel().execute();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            progressDialog.dismiss();
                if (error instanceof TimeoutError) {
                    error.printStackTrace();
                } else if (error instanceof NoConnectionError) {
                    error.printStackTrace();
                } else if (error instanceof AuthFailureError) {
                    error.printStackTrace();
                } else if (error instanceof ServerError) {
                    error.printStackTrace();
                } else if (error instanceof NetworkError) {
                    error.printStackTrace();
                } else if (error instanceof ParseError) {
                    error.printStackTrace();
                }

            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String ,String> params=new HashMap<>();
                loginData=loginDataMapper.getInfo("1");
                userid=loginData.user_id;
                params.put("userid",userid);
                System.out.println("userididid"+userid);
                return params;
            }
        };
        requestQueue.add(stringRequest);

    }
    class Asynvolly_cancel extends AsyncTask<Void,Void,Void>
    {
        int status;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try{
                JSONObject jsonObject=new JSONObject(responsefromvolly);
                JSONObject meta_data=jsonObject.getJSONObject("meta");
                status=meta_data.getInt("status");
                System.out.println("status cancel"+status);
            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            if(status==200)
            {
            }
            else
            {
                Toast.makeText(context,"oops..can't connect",Toast.LENGTH_SHORT).show();
            }
                    }
    }
}
