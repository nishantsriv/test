package com.buckwalk.Mystry.Profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Service;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.buckwalk.R;
import com.buckwalk.Register.Register;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.buckwalk.Mystry.Profile.Profile_Fragment.isNetworkAvailable;

/**
 * Created by Nishant on 12-04-2017.
 */

public class LocationService {


    public static class FetchCordinates extends AsyncTask<String, Void, String> {


        private double lati = 0.0;
        private double longi = 0.0;
        private LocationManager mLocationManager;
        private mLocationListener mListener;
        private Context context;

        public FetchCordinates(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {

            mListener = new mLocationListener();
            mLocationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

            mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, mListener);


        }


        @Override
        protected void onPostExecute(String result) {
            SharedPreferences preferences = context.getSharedPreferences("locationpref", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("lat", String.valueOf(lati));
            editor.putString("lng", String.valueOf(longi));
            editor.commit();
            context.sendBroadcast(new Intent("LOCATION"));

        /*Geocoder geo = new Geocoder(Register.this, Locale.getDefault());
        List<Address> add = new ArrayList<>();
        try {
            add = geo.getFromLocation(lati, longi, 1);
            location_edittext.setText(add.get(0).getAddressLine(0));
                *//*address.setText(add.get(0).getAddressLine(0) + " " + add.get(0).getAddressLine(1));
                city.setText(add.get(0).getSubAdminArea());
                state.setText(add.get(0).getAdminArea());
                country.setText(add.get(0).getCountryName());
                postal_code.setText(add.get(0).getPostalCode());*//*
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        }

        @Override
        protected String doInBackground(String... params) {
            // TODO Auto-generated method stub

            while (this.lati == 0.0) {

            }
            return null;
        }

        public class mLocationListener implements LocationListener {

            @Override
            public void onLocationChanged(Location location) {
                try {
                    lati = location.getLatitude();
                    longi = location.getLongitude();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onProviderDisabled(String provider) {
                Log.i("OnProviderDisabled", "OnProviderDisabled");
            }

            @Override
            public void onProviderEnabled(String provider) {
                Log.i("onProviderEnabled", "onProviderEnabled");
            }

            @Override
            public void onStatusChanged(String provider, int status,
                                        Bundle extras) {
                Log.i("onStatusChanged", "onStatusChanged");
            }
        }
    }

    public static void showAlertforgps(final Context context) {
        android.support.v7.app.AlertDialog.Builder alertDialog = new android.support.v7.app.AlertDialog.Builder(context);
        alertDialog.setTitle(R.string.gps_internet);
        alertDialog.setMessage("You need to connect to GPS for accessing your current location.");
        alertDialog.setPositiveButton("Enable", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                context.startActivity(i);
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    public static void getAddress(Context context) {
        LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            showAlertforgps(context);
        } else if (!isNetworkAvailable(context)) {
            showAlertforinternet(context);
        } else {
            FetchCordinates fetchCordinates = new FetchCordinates(context);
            fetchCordinates.execute();
        }
    }

    public static void showAlertforinternet(final Context context) {
        final android.support.v7.app.AlertDialog.Builder alertDialog = new android.support.v7.app.AlertDialog.Builder(context);
        alertDialog.setMessage(R.string.connect_internet);
        alertDialog.setPositiveButton("Retry", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                getAddress(context);
            }
        });
        alertDialog.setNegativeButton("Dismiss", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }


}
