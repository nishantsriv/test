package com.buckwalk.FirebaseCloudMessaging;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.buckwalk.R;
import com.buckwalk.Splash.Splash;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by nishant on 22-05-2017.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    int countNotification=0;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        RemoteMessage.Notification notification = remoteMessage.getNotification();

        Map<String, String> data = remoteMessage.getData();
        System.out.println("XXXX data"+data.toString());
        ShowNotification(notification, data);

        System.out.println("XXXX onmessagereceive From = "+remoteMessage.getFrom());

        if (remoteMessage.getData().size() > 0) {
            System.out.println("XXXX onmessagereceive Message data Payload = "+remoteMessage.getData());
        }

        if (remoteMessage.getNotification() != null) {
            System.out.println("XXXX onmessagereceive Message Notification Body = "+remoteMessage.getNotification().getBody());
            System.out.println("XXXX onmessagereceive Message Notification title = "+remoteMessage.getNotification().getTitle());
            System.out.println("XXXX onmessagereceive Message Notification  = "+remoteMessage.getNotification());
        }    }

    private void ShowNotification(RemoteMessage.Notification notification, Map<String, String> data) {

        Bitmap icon = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher_round);

        Intent intent = new Intent(this, Splash.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);


        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setContentTitle(data.get("title"))
                .setContentText(data.get("text"))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true).setColor(Color.BLACK)
                .setLargeIcon(icon)
                .setSmallIcon(R.mipmap.ic_launcher_round);


        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(100, notificationBuilder.build());
    }
}
