package com.buckwalk;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Host.HostFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AllRequests extends AppCompatActivity {

    private TabLayout errands_tablayout;
    private Toolbar toolbar;
    private Spinner toolbar_spinner;
    private DrawerLayout drawerLayout;
    private ImageView drawer_icon;
    private ViewPager accepted_requests_viewpager;
    ErrandsAllRequestsViewpagerAdapter errandsViewpagerAdapter;
    private ProgressDialog progressDialog;
    String[] city = {"Gurugram", "Jaipur", "Delhi"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accepted_requests);
        errands_tablayout=(TabLayout)findViewById(R.id.errands_all_request_tablayout);
        drawerLayout=(DrawerLayout)findViewById(R.id.errands_all_requests_drawer_layout);
        toolbar=(Toolbar)findViewById(R.id.toolbar);
//        progressDialog=progressDialog.show(AllRequests.this,"","Please Wait..");

        /*Divider*/
        LinearLayout linearLayout = (LinearLayout) errands_tablayout.getChildAt(0);
        linearLayout.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(getResources().getColor(R.color.grey));
        drawable.setSize(5, 1);
        linearLayout.setDividerPadding(20);
        linearLayout.setDividerDrawable(drawable);



        drawer_icon=(ImageView)findViewById(R.id.toolbar_drawer_icon);
        drawer_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            }
        });

        /*toolbar spinner*/
        toolbar_spinner=(Spinner)findViewById(R.id.toolbar_spinner);
        Drawable spinnerdrawable = toolbar_spinner.getBackground().getConstantState().newDrawable();
        spinnerdrawable.setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        toolbar_spinner.setBackground(spinnerdrawable);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_layout, city) {

            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextSize(13);
                return v;
            }

            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setGravity(Gravity.CENTER);
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        toolbar_spinner.setAdapter(adapter);
        /*toolbar spinner*/


       /*Viewpager*/
        accepted_requests_viewpager=(ViewPager)findViewById(R.id.accepted_request_viewpager);
        errandsViewpagerAdapter=new ErrandsAllRequestsViewpagerAdapter(getSupportFragmentManager());
        accepted_requests_viewpager.setAdapter(errandsViewpagerAdapter);
        accepted_requests_viewpager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(errands_tablayout));
       /*Viewpager*/

        /*Tabsetup*/
        errands_tablayout.addTab(errands_tablayout.newTab().setText("Accepted"));
        errands_tablayout.addTab(errands_tablayout.newTab().setText("Requested"));
        errands_tablayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.mystryColor));
        errands_tablayout.setSelectedTabIndicatorHeight(8);
        errands_tablayout.setTabTextColors(Color.LTGRAY, getResources().getColor(R.color.mystryColor));
        errands_tablayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                accepted_requests_viewpager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        /*Tabsetup*/
    }
}
