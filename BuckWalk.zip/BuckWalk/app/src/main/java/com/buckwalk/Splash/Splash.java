package com.buckwalk.Splash;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.buckwalk.Database.Database;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Database.UserTable;
import com.buckwalk.Home.Home;
import com.buckwalk.Login.Login;
import com.buckwalk.R;
import com.google.firebase.crash.FirebaseCrash;

public class Splash extends AppCompatActivity {

    Database db = new Database();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (db.data_exists("UserLogin")) {
                    Intent i = new Intent(Splash.this, Home.class);
                    startActivity(i);
                    finish();
                } else {
                    Intent i = new Intent(Splash.this, Login.class);
                    startActivity(i);
                    finish();
                }
            }
        }, 3000);
    }
}
