package com.buckwalk;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.buckwalk.Database.LoginData;
import com.buckwalk.Database.LoginDataMapper;
import com.buckwalk.Host.HostFile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Requested extends Fragment {
    private RecyclerView recyclerView;
    private RequestedAdapter requestedAdapter;
    LinearLayoutManager layoutManager;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    private String responsefromvolly,user_id;
    private Spinner errands_spinner;
    private ArrayList<Data_Requested> pending1_arraylist=new ArrayList<Data_Requested>();
    private ArrayList<Data_Requested> processing1_arraylist=new ArrayList<Data_Requested>();
    private ArrayList<Data_Requested> completed_arraylist=new ArrayList<Data_Requested>();
    private ProgressDialog progressDialog;
    LoginData loginData=new LoginData();
    LoginDataMapper loginDataMapper=new LoginDataMapper();
    private ArrayAdapter<CharSequence> adapspinner;
    HostFile hostFile=new HostFile();
  public Requested()
  {

  }

   @Nullable
   @Override
   public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
      View view=inflater.inflate(R.layout.fragment_requested,container,false);
       recyclerView=(RecyclerView)view.findViewById(R.id.requested_recyclerview);
       errands_spinner=(Spinner)view.findViewById(R.id.errands_accept_spinner);
       loginData=loginDataMapper.getInfo("1");
       user_id=loginData.user_id;
       System.out.println("userid in requested"+user_id);

       /*Spinner*/
       adapspinner=ArrayAdapter.createFromResource(getActivity(),R.array.job_status,android.R.layout.simple_spinner_item);
       adapspinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       errands_spinner.setAdapter(adapspinner);


       errands_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               if(errands_spinner.getSelectedItem().equals("Pending"))
               {
                   requestedAdapter=new RequestedAdapter(getActivity(),pending1_arraylist);
                   recyclerView.setAdapter(requestedAdapter);
               }
               else if(errands_spinner.getSelectedItem().equals("Processing"))
               {
                   recyclerView.setAdapter(new RequestedAdapter(getActivity(),processing1_arraylist));
               }
               else if(errands_spinner.getSelectedItem().equals("Completed"))
               {
                   recyclerView.setAdapter(new RequestedAdapter(getActivity(),completed_arraylist));
               }
           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {

           }
       });

       /*Spinner*/

       String url=hostFile.userrequested_errand(Integer.parseInt(user_id));
       System.out.println("url"+url);
       requestQueue= Volley.newRequestQueue(getActivity());
       stringRequest=new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
           @Override
           public void onResponse(String response) {
            responsefromvolly=response;
               System.out.println("responserequested"+responsefromvolly);
               new Asynvolly_requestederrands().execute();
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
               progressDialog.dismiss();
               if (error instanceof TimeoutError) {
                   error.printStackTrace();
               } else if (error instanceof NoConnectionError) {
                   error.printStackTrace();
               } else if (error instanceof AuthFailureError) {
                   error.printStackTrace();
               } else if (error instanceof ServerError) {
                   error.printStackTrace();
               } else if (error instanceof NetworkError) {
                   error.printStackTrace();
               } else if (error instanceof ParseError) {
                   error.printStackTrace();
               }
           }
       });
       requestQueue.add(stringRequest);
       layoutManager=new LinearLayoutManager(getActivity());
       recyclerView.setLayoutManager(layoutManager);
      return view;

   }

   class Asynvolly_requestederrands extends AsyncTask<Void,Void,Void>
   {int status;
       @Override
       protected void onPreExecute() {
           super.onPreExecute();
       }

       @Override
       protected Void doInBackground(Void... params) {
           try{
               JSONObject jsonObject=new JSONObject(responsefromvolly);
               JSONObject meta_data=jsonObject.getJSONObject("meta");
               status=meta_data.getInt("status");
               JSONArray jsonArray=jsonObject.getJSONArray("data");
               for(int i=0;i<jsonArray.length();i++) {
                   JSONObject jsonarrayobject = jsonArray.getJSONObject(i);
                   String id=jsonarrayobject.getString("id");
                   String errands_id=jsonarrayobject.getString("errands_id");
                   String customer_name=jsonarrayobject.getString("customer_name");
                   String service_type=jsonarrayobject.getString("service_type");
                   String pick_location=jsonarrayobject.getString("pick_location");
                   String drop_location=jsonarrayobject.getString("drop_location");
                   String errands_savedby=jsonarrayobject.getString("errands_savedby");
                   String proposed_amount=jsonarrayobject.getString("proposed_amount");
                   String customer_mob=jsonarrayobject.getString("customer_mob");
                   String errands_status=jsonarrayobject.getString("errands_status");
                   String saved_time=jsonarrayobject.getString("saved_time");
                   String valid=jsonarrayobject.getString("valid");
                   String name=jsonarrayobject.getString("name");
                   String mobile=jsonarrayobject.getString("mobile");
                   switch(errands_status)
                   {
                       case "2":
                           pending1_arraylist.add(new Data_Requested(id,errands_id,customer_name,service_type,pick_location,drop_location,errands_savedby,proposed_amount,
                                   customer_mob,errands_status,saved_time,valid,name,mobile));
                           break;
                       case "3":
                           processing1_arraylist.add(new Data_Requested(id,errands_id,customer_name,service_type,pick_location,drop_location,errands_savedby,proposed_amount,
                                   customer_mob,errands_status,saved_time,valid,name,mobile));
                           break;
                       case "4":
                           completed_arraylist.add(new Data_Requested(id,errands_id,customer_name,service_type,pick_location,drop_location,errands_savedby,proposed_amount,
                                   customer_mob,errands_status,saved_time,valid,name,mobile));
                           break;
                   }
               }
           }
           catch (JSONException e)
           {
               e.printStackTrace();
           }
           return null;
       }

       @Override
       protected void onPostExecute(Void aVoid) {

           if(status==200)
           {
               if(errands_spinner.getSelectedItem().equals("Pending"))
               {
                   requestedAdapter=new RequestedAdapter(getActivity(),pending1_arraylist);
                   recyclerView.setAdapter(requestedAdapter);
               }
               else if(errands_spinner.getSelectedItem().equals("Processing"))
               {
                   recyclerView.setAdapter(new RequestedAdapter(getActivity(),processing1_arraylist));
               }
               else if(errands_spinner.getSelectedItem().equals("Completed"))
               {
                   recyclerView.setAdapter(new RequestedAdapter(getActivity(),completed_arraylist));
               }
           }
           else
           {
               Toast.makeText(getActivity(),"Oops..something wrong",Toast.LENGTH_SHORT).show();
           }


       }
   }

}
